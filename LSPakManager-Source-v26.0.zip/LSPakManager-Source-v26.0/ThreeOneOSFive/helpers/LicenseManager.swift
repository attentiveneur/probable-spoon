import Combine
import Foundation
import Security
import UIKit

// ============================================================
// v21.0 · 真卡密门禁
// - 卡密由后台（ek.x8iu.com）签发，到期时间以服务端为准
// - 第一次验证后写进本机钥匙串，之后启动不再输入
// - 卡密到期 / 被后台禁用 → 立即锁回验证页
// - 断网时给 72 小时离线宽限，超时就必须联网校验
// ============================================================

@MainActor
final class LicenseManager: ObservableObject {

    enum Gate: Equatable {
        case checking          // 正在校验
        case locked            // 没卡密 / 没通过
        case unlocked          // 已激活且未到期
        case expired           // 卡密已到期
    }

    @Published private(set) var state: Gate = .checking
    @Published private(set) var expiration: Date?
    @Published private(set) var isBusy = false
    @Published private(set) var message: String?
    @Published private(set) var lastError: String?

    /// 校验接口（后台 api/verify.php）
    static let verifyEndpoint = "https://ek.x8iu.com/api/verify.php"
    /// 断网宽限
    static let offlineGrace: TimeInterval = 72 * 3600
    /// 本地时钟被往回拨的容忍秒数
    static let clockTolerance: TimeInterval = 600

    /// 永久卡在本地记成这个日期（2100-01-01），界面上不显示到期
    static let permanentDate = Date(timeIntervalSince1970: 4_102_444_800)

    private let service = "com.langshen.license.v21"
    private let kCode = "code"
    private let kExp = "exp"
    private let kCheck = "lastcheck"

    var isUnlocked: Bool { state == .unlocked }
    var savedCode: String { string(for: kCode) ?? "" }

    /// 还剩几天（永久卡 / 没有到期日 = nil）
    var remainingDays: Int? {
        guard let expiration else { return nil }
        if expiration >= Self.permanentDate { return nil }
        let cal = Calendar.current
        let from = cal.startOfDay(for: Date())
        let to = cal.startOfDay(for: expiration)
        return cal.dateComponents([.day], from: from, to: to).day
    }

    /// 永久卡（本地记的是 2100-01-01）
    var isPermanent: Bool {
        guard let expiration else { return false }
        return expiration >= Self.permanentDate
    }

    /// 界面上显示的到期文案：永久卡直接写「永久有效」
    var expiryLabel: String {
        guard expiration != nil else { return "待验证" }
        return isPermanent ? "永久有效" : expirationText
    }

    var expirationText: String {
        guard let expiration else { return "" }
        let f = DateFormatter()
        f.locale = Locale(identifier: "zh_CN")
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: expiration)
    }

    // MARK: - 启动

    /// 冷启动 / 回到前台时调用
    private var refreshing = false

    func refreshOnLaunch() async {
        guard !refreshing else { return }
        refreshing = true
        defer { refreshing = false }

        let code = savedCode
        guard !code.isEmpty else {
            state = .locked
            message = nil
            return
        }

        let cachedExp = date(for: kExp)
        let lastCheck = date(for: kCheck)
        let now = Date()

        // 本地时钟被往回拨 → 必须联网
        let clockRewound = (lastCheck != nil) && now.addingTimeInterval(Self.clockTolerance) < lastCheck!

        if let cachedExp {
            if cachedExp <= now && !clockRewound {
                // 已经到期：再给服务端一次机会（可能后台续期了），否则锁死
                let ok = await verify(code: code, silent: true)
                if ok { return }
                state = .expired
                expiration = cachedExp
                message = "卡密已于 \(expirationText) 到期"
                return
            }
            // 还有效 + 在宽限期内 → 直接放行，不打扰用户
            if let lastCheck, now.timeIntervalSince(lastCheck) < Self.offlineGrace, !clockRewound {
                state = .unlocked
                expiration = cachedExp
                return
            }
        }

        // 需要联网确认
        isBusy = true
        defer { isBusy = false }
        let ok = await verify(code: code, silent: true)
        if ok { return }

        // 联网失败：缓存还没过期且没超过宽限，就先放行
        if let cachedExp, cachedExp > now, !clockRewound,
           let lastCheck, now.timeIntervalSince(lastCheck) < Self.offlineGrace {
            state = .unlocked
            expiration = cachedExp
            return
        }
        if let cachedExp, cachedExp <= now {
            state = .expired
            expiration = cachedExp
            message = "卡密已于 \(expirationText) 到期"
        } else {
            state = .locked
            message = lastError ?? "暂时无法连接验证服务器，请检查网络后重试"
        }
    }

    // MARK: - 激活

    func activate(code rawCode: String) async {
        let code = rawCode.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !code.isEmpty, !isBusy else { return }
        isBusy = true
        message = nil
        defer { isBusy = false }

        let ok = await verify(code: code, silent: false)
        if ok {
            save(code, for: kCode)
            saveTimestamp(Date(), for: kCheck)
            state = .unlocked
            message = nil
        } else {
            state = .locked
            message = lastError ?? "卡密不正确"
        }
    }

    /// 续费：输入一张新卡密，把它带的时长加到当前这张上
    func renew(code rawCode: String) async -> (ok: Bool, msg: String) {
        let code = rawCode.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        guard !code.isEmpty else { return (false, "先把续费卡密填进来") }
        guard !isBusy else { return (false, "正在验证，等这一下跑完再试") }

        let current = savedCode
        if current.isEmpty {
            // 还没绑过卡密，就当正常激活
            await activate(code: code)
            return (isUnlocked, isUnlocked ? "这张卡密已经开通" : (message ?? "卡密不正确"))
        }
        if current.uppercased() == code {
            return (false, "这就是现在用的这张卡，换一张续费卡再试")
        }

        isBusy = true
        defer { isBusy = false }

        let ok = await verify(code: code, silent: false, mode: "renew", base: current)
        if ok {
            saveTimestamp(Date(), for: kCheck)
            state = .unlocked
            message = nil
            return (true, "续费成功，到期时间已经往后延")
        }
        return (false, lastError ?? "续费失败，这张卡密不可用")
    }

    func deactivate() {
        delete(kCode); delete(kExp); delete(kCheck)
        state = .locked
        expiration = nil
        message = nil
    }

    // MARK: - 网络校验

    /// 返回 true = 卡密有效且未到期
    private func verify(code: String, silent: Bool, mode: String = "", base: String = "") async -> Bool {
        lastError = nil

        var req = URLRequest(url: URL(string: Self.verifyEndpoint)!)
        req.httpMethod = "POST"
        req.timeoutInterval = 15
        req.setValue("application/x-www-form-urlencoded; charset=utf-8", forHTTPHeaderField: "Content-Type")
        req.setValue("浪神/23.0", forHTTPHeaderField: "User-Agent")

        let device = UIDevice.current.identifierForVendor?.uuidString ?? "unknown"
        var body = [
            "code": code,
            "device": device,
            "ver": "23.0",
            "t": String(Int(Date().timeIntervalSince1970))
        ]
        if !mode.isEmpty { body["mode"] = mode }
        if !base.isEmpty { body["base"] = base }
        let encoded = body
        .map { "\($0.key)=\(Self.escape($0.value))" }
        .joined(separator: "&")
        req.httpBody = Data(encoded.utf8)

        do {
            let (data, resp) = try await URLSession.shared.data(for: req)
            guard let http = resp as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
                lastError = "验证服务器返回异常，请稍后再试"
                return false
            }
            guard let json = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                lastError = "验证服务器返回内容看不懂，请联系管理员"
                return false
            }

            let ok = (json["ok"] as? Bool) ?? ((json["ok"] as? Int) == 1)
            if ok {
                let expValue: Double = {
                    if let n = json["exp"] as? NSNumber { return n.doubleValue }
                    if let s = json["exp"] as? String, let d = Double(s) { return d }
                    return 0
                }()
                if expValue > 0 {
                    let date = Date(timeIntervalSince1970: expValue)
                    if date <= Date() {
                        saveTimestamp(date, for: kExp)
                        saveTimestamp(Date(), for: kCheck)
                        expiration = date
                        lastError = "卡密已于 \(expirationText) 到期"
                        return false
                    }
                    saveTimestamp(date, for: kExp)
                    expiration = date
                } else {
                    // 后台发的是「永久」：本地记一个很远的日期，界面上不显示到期
                    saveTimestamp(Self.permanentDate, for: kExp)
                    expiration = nil
                }
                saveTimestamp(Date(), for: kCheck)
                return true
            }

            let msg = (json["msg"] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines)
            lastError = (msg?.isEmpty == false) ? msg : "卡密不正确或已失效"
            return false
        } catch {
            lastError = "连不上验证服务器，请检查网络后再试"
            return false
        }
    }

    private static func escape(_ value: String) -> String {
        var allowed = CharacterSet.alphanumerics
        allowed.insert(charactersIn: "-._~")
        return value.addingPercentEncoding(withAllowedCharacters: allowed) ?? value
    }

    // MARK: - 钥匙串

    private func string(for account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func save(_ value: String, for account: String) {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(base as CFDictionary)
        var item = base
        item[kSecValueData as String] = Data(value.utf8)
        item[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        SecItemAdd(item as CFDictionary, nil)
    }

    private func saveTimestamp(_ date: Date, for account: String) {
        save(String(Int(date.timeIntervalSince1970)), for: account)
    }

    private func date(for account: String) -> Date? {
        guard let raw = string(for: account), let secs = TimeInterval(raw) else { return nil }
        return Date(timeIntervalSince1970: secs)
    }

    private func delete(_ account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
}
