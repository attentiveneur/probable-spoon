import SwiftUI
import UIKit
import AVFoundation
import Combine
import UniformTypeIdentifiers
import CryptoKit
import Security

struct ContentView: View {
    @Environment(\.scenePhase) private var scenePhase
    @EnvironmentObject private var appState: AppState
    @EnvironmentObject private var license: LicenseManager
    @ObservedObject private var importer = PaksImporter.shared
    @ObservedObject private var appLog = AppLog.shared

    @State private var showSettings = false
    @State private var showCleaner = false
    @State private var showPicker = false
    @State private var showGamePakList = false
    @State private var showAdvanced = false

    @StateObject private var patchStore = PatchProjectStore()
    @State private var patchOperationBusy = false
    @State private var patchMessage = "READY — SELECT A PATCH"
    @State private var aimDragEnabled = false
    @State private var aimNeckEnabled = false
    @State private var hspeitoffEnabled = false
    @State private var hyperBalamagicaEnabled = false
    @State private var aimBodyPackageEnabled = false
    @State private var aimChestPackageEnabled = false
    @State private var magicEnabled = false

    private let ticker = Timer.publish(every: 6, on: .main, in: .common).autoconnect()

    var body: some View {
        ZStack {
            AnimatedHyperBackdrop()
                .ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 14) {
                    brandHeader
                    warningCard
                    kernelCard
                    quadGrid
                    switchRow
                    statsRow
                    hintLine
                    secondaryRow
                    advancedSection
                    logCard
                    developerCredits
                }
                .padding(.horizontal, 16)
                .padding(.top, 14)
                .padding(.bottom, 26)
            }

            resultPopupLayer
                .zIndex(99)
        }
        .preferredColorScheme(.dark)
        .sheet(isPresented: $showSettings) {
            SettingsView()
        }
        .sheet(isPresented: $showCleaner) {
            CleanerView()
        }
        .sheet(isPresented: $showPicker) {
            PakDocumentPicker { urls in
                importer.add(urls: urls)
            }
        }
        .sheet(isPresented: $showGamePakList) {
            GamePakListSheet(importer: importer)
        }
        .sheet(item: $patchStore.passwordRequest, onDismiss: patchStore.cancelUnlock) { _ in
            PatchUnlockPrompt(store: patchStore)
        }
        .onAppear {
            syncPatchStates()
            importer.refresh()
        }
        .onReceive(ticker) { _ in
            if !importer.busy && !importer.containerFound {
                importer.refresh()
            }
        }
        .onChange(of: scenePhase) { phase in
            guard phase == .active else { return }
            importer.refresh()
            guard !patchOperationBusy else { return }
            syncPatchStates()
            patchMessage = "READY — SELECT A PATCH"
        }
    }

    // MARK: - 结果弹窗（自绘浮层，不走系统 alert，保证一定弹得出来）

    private var resultPopupLayer: some View {
        Group {
            if let item = importer.pendingAlert {
                ZStack {
                    Color.black.opacity(0.66)
                        .ignoresSafeArea()
                        .onTapGesture { importer.dismissAlert() }

                    VStack(alignment: .leading, spacing: 13) {
                        HStack(spacing: 10) {
                            Image(systemName: item.success
                                  ? "checkmark.circle.fill"
                                  : "exclamationmark.triangle.fill")
                                .font(.system(size: 20, weight: .bold))
                                .foregroundStyle(item.success ? HomeTheme.accent : HomeTheme.yellow)

                            Text(item.title)
                                .font(.system(size: 17, weight: .black, design: .rounded))
                                .foregroundStyle(.white)
                                .lineLimit(2)
                                .minimumScaleFactor(0.8)

                            Spacer(minLength: 0)
                        }

                        Text(item.message)
                            .font(.system(size: 13, weight: .medium))
                            .foregroundStyle(.white.opacity(0.88))
                            .fixedSize(horizontal: false, vertical: true)
                            .lineSpacing(3)

                        Button {
                            importer.dismissAlert()
                        } label: {
                            Text("好")
                                .font(.system(size: 14, weight: .black, design: .rounded))
                                .foregroundStyle(Color.black)
                                .frame(maxWidth: .infinity, minHeight: 42)
                                .background(
                                    HomeTheme.accent,
                                    in: RoundedRectangle(cornerRadius: 12, style: .continuous)
                                )
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(18)
                    .frame(maxWidth: 330)
                    .background(
                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                            .fill(Color(red: 0.05, green: 0.10, blue: 0.08))
                    )
                    .overlay(
                        RoundedRectangle(cornerRadius: 20, style: .continuous)
                            .stroke(HomeTheme.accent.opacity(0.55), lineWidth: 1.2)
                    )
                    .shadow(color: Color.black.opacity(0.55), radius: 24, y: 10)
                    .padding(.horizontal, 30)
                }
                .transition(.opacity.combined(with: .scale(scale: 0.92)))
            }
        }
        .animation(.easeOut(duration: 0.18), value: importer.pendingAlert?.id)
    }

    // MARK: - 顶部

    private var brandHeader: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 2) {
                Text("浪神文件管理器")
                    .font(.system(size: 22, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text("PAK 注入 / 修复")
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .tracking(0.6)
                    .foregroundStyle(HomeTheme.accent.opacity(0.92))
            }

            Spacer()

            Button {
                showSettings = true
            } label: {
                Image(systemName: "gearshape.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(HomeTheme.accent)
                    .frame(width: 44, height: 44)
                    .background(Color.black.opacity(0.34), in: Circle())
                    .overlay(Circle().stroke(HomeTheme.accent.opacity(0.45), lineWidth: 1))
            }
            .buttonStyle(.plain)
            .accessibilityLabel("设置")
        }
    }

    private var warningCard: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack(spacing: 7) {
                Text(importer.containerFound ? "✅" : "⚠️")
                    .font(.system(size: 14, weight: .bold))
                Text(warningHeadline)
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .foregroundStyle(HomeTheme.warnText)
                    .lineLimit(2)
                    .minimumScaleFactor(0.85)
                Spacer(minLength: 0)
            }

            Text("游戏内 pak/sig \(importer.paksCount) 个 · 待导入 \(importer.inboxFiles.count) 个 · 已导入 \(importer.importedFiles.count) 个")
                .font(.system(size: 10, weight: .semibold, design: .rounded))
                .foregroundStyle(HomeTheme.warnText.opacity(0.86))
                .lineLimit(2)
                .minimumScaleFactor(0.8)

            Text(appState.exploitStatus.isSuccess ? "已拿到全盘读写 → 可以直接写进游戏目录" : "这台设备没给全盘权限 → 用「改本机的包」模式")
                .font(.system(size: 10, weight: .semibold, design: .rounded))
                .foregroundStyle(HomeTheme.warnText.opacity(0.72))
                .lineLimit(2)
                .minimumScaleFactor(0.8)
        }
        .padding(.horizontal, 13)
        .padding(.vertical, 11)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(HomeTheme.warnBackground, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(HomeTheme.warnBorder, lineWidth: 1)
        )
    }

    private var warningHeadline: String {
        if importer.containerFound {
            let who = importer.matchedBundleID.isEmpty ? "" : "（\(importer.matchedBundleID)）"
            return "已拿到游戏目录\(who) —— 可以直接导入"
        }
        return "还没拿到游戏目录 —— 先点下面「一键激活内核」"
    }

    // MARK: - 内核引擎

    private var kernelCard: some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack(spacing: 8) {
                Label("内核引擎", systemImage: "bolt.fill")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .tracking(1.0)
                    .foregroundStyle(HomeTheme.accent)
                Spacer()
                Text(kernelStatusText)
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .foregroundStyle(kernelStatusColor)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 4)
                    .background(kernelStatusColor.opacity(0.14), in: Capsule())
            }

            Text(kernelSubtitle)
                .font(.system(size: 10, weight: .medium, design: .rounded))
                .foregroundStyle(.white.opacity(0.62))
                .fixedSize(horizontal: false, vertical: true)

            Button {
                appState.runKernelExploitIfNeeded()
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: "bolt.fill")
                        .font(.system(size: 15, weight: .bold))
                    Text(appState.kernelExploitRunning ? "正在激活…（10~30 秒）" : "⚡ 一键激活内核 · 全盘读写")
                        .font(.system(size: 13, weight: .black, design: .rounded))
                        .lineLimit(1)
                        .minimumScaleFactor(0.75)
                    Spacer(minLength: 0)
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 14)
                .padding(.vertical, 14)
                .frame(maxWidth: .infinity)
                .background(HomeTheme.purple, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(Color.white.opacity(0.18), lineWidth: 1)
                )
            }
            .buttonStyle(.plain)
            .disabled(appState.kernelExploitRunning || appState.exploitStatus.isSuccess || !appState.isSupported)
            .opacity((appState.kernelExploitRunning || appState.exploitStatus.isSuccess || !appState.isSupported) ? 0.55 : 1)
        }
        .padding(15)
        .background(HomeTheme.card, in: RoundedRectangle(cornerRadius: 20, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .stroke(HomeTheme.accent.opacity(0.30), lineWidth: 1)
        )
    }

    private var kernelStatusText: String {
        if appState.kernelExploitRunning { return "激活中…" }
        if case .success = appState.exploitStatus { return "已激活" }
        if case .failed = appState.exploitStatus { return "失败" }
        if case .unsupported = appState.exploitStatus { return "不支持本系统" }
        return "未激活"
    }

    private var kernelStatusColor: Color {
        if appState.kernelExploitRunning { return HomeTheme.yellow }
        if case .success = appState.exploitStatus { return HomeTheme.accent }
        if case .failed = appState.exploitStatus { return HomeTheme.red }
        if case .unsupported = appState.exploitStatus { return HomeTheme.red }
        return HomeTheme.yellow
    }

    private var kernelSubtitle: String {
        if appState.kernelExploitRunning {
            return "正在提权，屏幕可能会卡一下，别退出、别切后台。"
        }
        if case .success = appState.exploitStatus {
            return "内核读写和沙盒逃逸都在了，可以直接把 pak 写进游戏 Paks。"
        }
        if case .failed = appState.exploitStatus {
            return "这次没成功（漏洞有概率失败）。把 App 划掉重开，再点一次。"
        }
        if case .unsupported(let version) = appState.exploitStatus {
            return "iOS \(version) 不在内核引擎支持范围（支持 17.0–17.7 / 18.0–18.7.1 / 26.0–26.6.1 / 27 Beta）。这台机器只能用 App 内的包，写不进游戏目录。"
        }
        return "点一下，自动完成内核读写和沙盒逃逸，之后才能写进游戏目录。"
    }

    // MARK: - 四宫格

    private var quadGrid: some View {
        LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
            quadCard(title: "① 注入",
                     subtitle: "待导入 \(importer.inboxFiles.count) 个",
                     systemImage: "doc.fill",
                     tint: HomeTheme.green) {
                importer.importAll()
            }

            quadCard(title: "② 修复",
                     subtitle: importer.importedFiles.isEmpty ? "还没导入过" : "已导入 \(importer.importedFiles.count) 个",
                     systemImage: "wrench.fill",
                     tint: HomeTheme.red) {
                importer.deleteImported()
            }

            quadCard(title: "③ 从手机里选文件",
                     subtitle: "选完自动进「待导入」",
                     systemImage: "iphone",
                     tint: HomeTheme.blue) {
                showPicker = true
            }

            quadCard(title: "④ 全盘找 pak",
                     subtitle: "看看游戏里都有啥",
                     systemImage: "magnifyingglass",
                     tint: HomeTheme.purple) {
                importer.refreshGamePaks()
                showGamePakList = true
            }
        }
    }

    private func quadCard(title: String, subtitle: String, systemImage: String, tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 8) {
                Image(systemName: systemImage)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 34, height: 34)
                    .background(Color.black.opacity(0.22), in: RoundedRectangle(cornerRadius: 10, style: .continuous))

                Text(title)
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.72)

                Text(subtitle)
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.82))
                    .lineLimit(1)
                    .minimumScaleFactor(0.72)
            }
            .frame(maxWidth: .infinity, minHeight: 118, alignment: .leading)
            .padding(13)
            .background(tint.opacity(0.62), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .stroke(Color.white.opacity(0.16), lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .disabled(importer.busy)
        .opacity(importer.busy ? 0.55 : 1)
    }

    // MARK: - 开关行

    private var switchRow: some View {
        HStack(spacing: 9) {
            Button {
                importer.setBackup(!importer.backupEnabled)
            } label: {
                chip(title: "💾 备份：\(importer.backupEnabled ? "开" : "关")",
                     tint: importer.backupEnabled ? HomeTheme.green : Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)

            Button {
                importer.setWipeBackup(!importer.wipeBackupEnabled)
            } label: {
                chip(title: "🧹 连备份删：\(importer.wipeBackupEnabled ? "开" : "关")",
                     tint: importer.wipeBackupEnabled ? HomeTheme.green.opacity(0.82) : Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)

            Button {
                importer.refresh()
            } label: {
                chip(title: "🔄 刷新", tint: Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)
        }
    }

    private func chip(title: String, tint: Color) -> some View {
        Text(title)
            .font(.system(size: 11, weight: .black, design: .rounded))
            .foregroundStyle(.white)
            .lineLimit(1)
            .minimumScaleFactor(0.7)
            .frame(maxWidth: .infinity, minHeight: 40)
            .padding(.horizontal, 6)
            .background(tint, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 12, style: .continuous)
                    .stroke(Color.white.opacity(0.12), lineWidth: 1)
            )
    }

    // MARK: - 数字框

    private var statsRow: some View {
        HStack(spacing: 10) {
            statBox(value: importer.inboxFiles.count, title: "待导入")
            statBox(value: importer.importedFiles.count, title: "已导入")
            statBox(value: importer.paksCount, title: "游戏里的包")
        }
    }

    private func statBox(value: Int, title: String) -> some View {
        VStack(spacing: 3) {
            Text("\(value)")
                .font(.system(size: 22, weight: .black, design: .rounded))
                .foregroundStyle(HomeTheme.accent)
            Text(title)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.60))
                .lineLimit(1)
                .minimumScaleFactor(0.75)
        }
        .frame(maxWidth: .infinity, minHeight: 62)
        .background(HomeTheme.card, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(HomeTheme.accent.opacity(0.18), lineWidth: 1)
        )
    }

    private var hintLine: some View {
        Text(importerHint)
            .font(.system(size: 10, weight: .medium, design: .rounded))
            .foregroundStyle(.white.opacity(0.52))
            .multilineTextAlignment(.leading)
            .fixedSize(horizontal: false, vertical: true)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var importerHint: String {
        if importer.busy { return "正在处理，别退出 App，也别切后台。" }
        if !importer.lastResult.isEmpty { return importer.lastResult }
        if importer.inboxFiles.isEmpty {
            return "待导入是空的：点「③ 从手机里选文件」，或者在文件 App 里长按 pak → 共享 → 浪神文件管理器，也会自动进来。"
        }
        return "点「注入」直接覆盖游戏里的同名原件（备份开着就先存一份），点「修复」把导进去的那几个从游戏里直接删掉，不还原原件。"
    }

    private var secondaryRow: some View {
        HStack(spacing: 9) {
            Button {
                importer.claimImported()
            } label: {
                chip(title: "📥 认领已导入的", tint: Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)

            Button {
                importer.clearStaleRecords()
            } label: {
                chip(title: "🧹 清掉失效记录", tint: Color.black.opacity(0.40))
            }
            .buttonStyle(.plain)
        }
    }

    // MARK: - 进阶（原功能全在这里）

    private var advancedSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    showAdvanced.toggle()
                }
            } label: {
                HStack(spacing: 8) {
                    Text("Aa 改字（进阶 · 跟导入无关）")
                        .font(.system(size: 12, weight: .bold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.86))
                    Spacer()
                    Image(systemName: showAdvanced ? "chevron.up" : "chevron.down")
                        .font(.system(size: 11, weight: .black))
                        .foregroundStyle(HomeTheme.accent)
                }
                .padding(.horizontal, 14)
                .padding(.vertical, 12)
                .background(HomeTheme.card, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 14, style: .continuous)
                        .stroke(HomeTheme.accent.opacity(0.16), lineWidth: 1)
                )
            }
            .buttonStyle(.plain)

            if showAdvanced {
                patchOptions
                gameLaunchPanel
                Button {
                    showCleaner = true
                } label: {
                    Label("清理缓存与临时文件", systemImage: "trash.slash.fill")
                        .font(.system(size: 12, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity, minHeight: 48)
                        .background(Color.black.opacity(0.42), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: 14, style: .continuous)
                                .stroke(HomeTheme.accent.opacity(0.34), lineWidth: 1)
                        )
                }
                .buttonStyle(.plain)
            }
        }
    }

    // MARK: - 运行记录

    private var logCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 8) {
                Label("运行记录", systemImage: "list.bullet.rectangle")
                    .font(.system(size: 12, weight: .black, design: .rounded))
                    .tracking(0.8)
                    .foregroundStyle(HomeTheme.accent)
                Spacer()
                Button {
                    appLog.entries.removeAll()
                } label: {
                    Text("清空")
                        .font(.system(size: 10, weight: .bold, design: .rounded))
                        .foregroundStyle(.white.opacity(0.62))
                        .padding(.horizontal, 9)
                        .padding(.vertical, 4)
                        .background(Color.white.opacity(0.08), in: Capsule())
                }
                .buttonStyle(.plain)
            }

            if recentLogLines.isEmpty {
                Text("还没有记录。点上面的按钮，这里会一行一行写下来。")
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.42))
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                VStack(alignment: .leading, spacing: 5) {
                    ForEach(Array(recentLogLines.enumerated()), id: \.offset) { _, line in
                        Text(line)
                            .font(.system(size: 10, weight: .medium, design: .monospaced))
                            .foregroundStyle(.white.opacity(0.70))
                            .lineLimit(2)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
            }
        }
        .padding(14)
        .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous)
                .stroke(HomeTheme.accent.opacity(0.16), lineWidth: 1)
        )
    }

    private var recentLogLines: [String] {
        let tail = appLog.entries.suffix(8)
        return tail.map { line in
            if line.hasPrefix("[OGIOS] ") {
                return String(line.dropFirst(8))
            }
            return line
        }
    }

    // MARK: - 补丁（进阶区保留原功能）

    private var patchOptions: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                panelTitle("PATCH OPTIONS", icon: "bolt.fill")
                Spacer()
                Text("SELECT TO ENABLE")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }

            LazyVGrid(columns: [GridItem(.flexible(), spacing: 12), GridItem(.flexible(), spacing: 12)], spacing: 12) {
                patchCard(name: "Aim Drag", target: "FREE FIRE • NORMAL", package: "OGIOS File (6).3105", color: HomeTheme.accent, state: $aimDragEnabled)
                patchCard(name: "Aim Neck", target: "FREE FIRE • NORMAL", package: "OGIOS File (7).3105", color: HomeTheme.blue, state: $aimNeckEnabled)
                patchCard(name: "Antenna", target: "FREE FIRE • NORMAL", package: "OGIOS File (8).3105", color: HomeTheme.blue, state: $hspeitoffEnabled)
                patchCard(name: "144 FPS", target: "FREE FIRE • NORMAL", package: "OGIOS File (10).3105", color: HomeTheme.blue, state: $hyperBalamagicaEnabled)
                patchCard(name: "Aim Body", target: "FREE FIRE • NORMAL", package: "OGIOS File (12).3105", color: HomeTheme.accent, state: $aimBodyPackageEnabled)
                patchCard(name: "Aim Chest", target: "FREE FIRE • NORMAL", package: "OGIOS File (2).3105", color: HomeTheme.blue, state: $aimChestPackageEnabled)
                patchCard(name: "Magic", target: "FREE FIRE • NORMAL", package: "OGIOS File (14).3105", color: HomeTheme.accent, state: $magicEnabled)
            }

            HStack(spacing: 8) {
                Circle().fill(patchMessage.localizedCaseInsensitiveContains("successful") ? HomeTheme.accent : HomeTheme.yellow).frame(width: 7, height: 7)
                Text(patchOperationBusy ? "PROCESSING PATCH…" : patchMessage)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.72))
                    .lineLimit(2)
                Spacer()
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(Color.black.opacity(0.34), in: Capsule())
        }
    }

    private func patchCard(name: String, target: String, package: String, color: Color, state: Binding<Bool>) -> some View {
        PatchOptionCard(name: name, target: target, color: color, isEnabled: state, isBusy: patchOperationBusy) {
            togglePatch(packageFilename: package, state: state)
        }
    }

    private var gameLaunchPanel: some View {
        VStack(alignment: .leading, spacing: 12) {
            panelTitle("LAUNCH GAME", icon: "arrow.up.forward.app.fill")
            HStack(spacing: 12) {
                launchButton(title: "FF NORMAL", subtitle: "Free Fire Normal", color: HomeTheme.accent, scheme: "freefireth")
                lockedLaunchButton(title: "FF MAX", subtitle: "Locked • Coming Soon", color: HomeTheme.blue)
            }
        }
    }

    private func launchButton(title: String, subtitle: String, color: Color, scheme: String) -> some View {
        Button { openGame(scheme: scheme) } label: {
            VStack(alignment: .leading, spacing: 7) {
                Image(systemName: "arrow.up.right.square.fill")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(color)
                Text(title)
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(subtitle)
                    .font(.system(size: 10, weight: .medium, design: .rounded))
                    .foregroundStyle(.white.opacity(0.5))
            }
            .frame(maxWidth: .infinity, minHeight: 82, alignment: .leading)
            .padding(.horizontal, 14)
            .background(Color.black.opacity(0.40), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(color.opacity(0.38), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private func lockedLaunchButton(title: String, subtitle: String, color: Color) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Image(systemName: "lock.fill")
                .font(.system(size: 18, weight: .bold))
                .foregroundStyle(color.opacity(0.72))
            Text(title)
                .font(.system(size: 13, weight: .black, design: .rounded))
                .foregroundStyle(.white.opacity(0.72))
            Text(subtitle)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .foregroundStyle(color.opacity(0.72))
        }
        .frame(maxWidth: .infinity, minHeight: 82, alignment: .leading)
        .padding(.horizontal, 14)
        .background(Color.black.opacity(0.28), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(color.opacity(0.24), lineWidth: 1))
        .opacity(0.72)
        .accessibilityLabel("FF MAX locked, coming soon")
    }

    private func panelTitle(_ title: String, icon: String) -> some View {
        Label(title, systemImage: icon)
            .font(.system(size: 12, weight: .black, design: .rounded))
            .tracking(1.4)
            .foregroundStyle(HomeTheme.accent)
    }

    private func syncPatchStates() {
        aimDragEnabled = isPatchActive("OGIOS File (6).3105")
        aimNeckEnabled = isPatchActive("OGIOS File (7).3105")
        hspeitoffEnabled = isPatchActive("OGIOS File (8).3105")
        hyperBalamagicaEnabled = isPatchActive("OGIOS File (10).3105")
        aimBodyPackageEnabled = isPatchActive("OGIOS File (12).3105")
        aimChestPackageEnabled = isPatchActive("OGIOS File (2).3105")
        magicEnabled = isPatchActive("OGIOS File (14).3105")
    }

    private func isPatchActive(_ packageFilename: String) -> Bool {
        patchStore.items.first(where: { $0.packageURL.lastPathComponent.caseInsensitiveCompare(packageFilename) == .orderedSame })
            .flatMap { DevicePatchService.latestReceipt(projectID: $0.id) } != nil
    }

    private enum PatchActionResult {
        case applied
        case restored
        case unavailable(String)
    }

    private func setPatchState(for packageFilename: String, enabled: Bool) {
        switch packageFilename {
        case "OGIOS File (6).3105": aimDragEnabled = enabled
        case "OGIOS File (7).3105": aimNeckEnabled = enabled
        case "OGIOS File (8).3105": hspeitoffEnabled = enabled
        case "OGIOS File (10).3105": hyperBalamagicaEnabled = enabled
        case "OGIOS File (12).3105": aimBodyPackageEnabled = enabled
        case "OGIOS File (2).3105": aimChestPackageEnabled = enabled
        case "OGIOS File (14).3105": magicEnabled = enabled
        default: break
        }
    }

    private func togglePatch(packageFilename: String, state: Binding<Bool>) {
        guard !patchOperationBusy else { return }
        guard let item = patchStore.items.first(where: { $0.packageURL.lastPathComponent.caseInsensitiveCompare(packageFilename) == .orderedSame }) else {
            patchMessage = "ERROR — PACKAGE NOT FOUND"
            log("patch: package not found: \(packageFilename)")
            return
        }

        let wasEnabled = state.wrappedValue
        patchOperationBusy = true
        patchMessage = "PROCESSING — \(packageFilename)"
        let project = item.project
        let projectID = item.id

        DispatchQueue.global(qos: .userInitiated).async {
            let result: PatchActionResult
            do {
                if wasEnabled {
                    guard let receipt = DevicePatchService.latestReceipt(projectID: projectID) else {
                        result = .unavailable("NO ACTIVE RECEIPT — NOTHING TO RESTORE")
                        DispatchQueue.main.async {
                            self.setPatchState(for: packageFilename, enabled: false)
                            self.patchMessage = "OFF — NO ACTIVE PATCH FOUND"
                            self.patchOperationBusy = false
                        }
                        return
                    }
                    try DevicePatchService.restore(receipt: receipt)
                    result = .restored
                } else {
                    guard let project else {
                        result = .unavailable("PASSWORD REQUIRED — UNLOCK PACKAGE")
                        DispatchQueue.main.async {
                            self.patchStore.requestUnlock(for: item)
                            self.patchMessage = "PASSWORD REQUIRED — ENTER PACKAGE PASSWORD"
                            self.patchOperationBusy = false
                        }
                        return
                    }
                    _ = try DevicePatchService.apply(project: project)
                    result = .applied
                }
            } catch {
                result = .unavailable("FAILED — \(String(describing: error))")
            }

            DispatchQueue.main.async {
                switch result {
                case .applied:
                    self.setPatchState(for: packageFilename, enabled: true)
                    self.patchMessage = "Inject Successful — \(packageFilename)"
                    PatchAudioFeedback.bypassActivated()
                case .restored:
                    self.setPatchState(for: packageFilename, enabled: false)
                    self.patchMessage = "Restore Successful — \(packageFilename)"
                    PatchAudioFeedback.originalRestored()
                case .unavailable(let message):
                    self.patchMessage = message
                }
                self.patchOperationBusy = false
            }
        }
    }

    private func openGame(scheme: String) {
        guard let url = URL(string: "\(scheme)://") else { return }
        UIApplication.shared.open(url, options: [:]) { success in
            log("launch: \(scheme) success=\(success)")
        }
    }

    private var developerCredits: some View {
        Text("浪神文件管理器 · 内核引擎来自 OGIOS")
            .font(.system(size: 10, weight: .bold, design: .rounded))
            .foregroundStyle(.white.opacity(0.55))
            .multilineTextAlignment(.center)
            .frame(maxWidth: .infinity)
            .padding(.top, 4)
    }
}

// MARK: - 首页配色

enum HomeTheme {
    static let accent = Color(red: 0.38, green: 0.88, blue: 1.00)
    static let green = Color(red: 0.30, green: 0.72, blue: 1.00)
    static let red = Color(red: 0.90, green: 0.36, blue: 0.42)
    static let blue = Color(red: 0.30, green: 0.62, blue: 1.00)
    static let purple = Color(red: 0.58, green: 0.52, blue: 1.00)
    static let yellow = Color(red: 0.98, green: 0.80, blue: 0.42)
    static let card = Color(red: 0.02, green: 0.06, blue: 0.12).opacity(0.80)
    static let warnBackground = Color(red: 0.85, green: 0.66, blue: 0.16).opacity(0.22)
    static let warnBorder = Color(red: 0.96, green: 0.78, blue: 0.29).opacity(0.55)
    static let warnText = Color(red: 0.99, green: 0.90, blue: 0.62)
}

// MARK: - 游戏内 pak 列表

struct GamePakListSheet: View {
    @ObservedObject var importer: PaksImporter
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            Group {
                if importer.gamePaks.isEmpty {
                    VStack(spacing: 12) {
                        Image(systemName: "shippingbox")
                            .font(.system(size: 30, weight: .medium))
                            .foregroundStyle(.secondary)
                        Text(importer.containerFound ? "游戏 Paks 里还没有 pak" : "还没定位到游戏目录")
                            .font(.headline)
                        Text(importer.containerFound
                             ? "先启动一次游戏，让它生成 Paks 目录，再回来点刷新。"
                             : "先回首页点「⚡ 一键激活内核」，状态变绿之后再点④。")
                            .font(.footnote)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding(28)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List {
                        Section {
                            ForEach(importer.gamePaks) { pak in
                                HStack(spacing: 10) {
                                    Image(systemName: "doc.fill")
                                        .foregroundStyle(HomeTheme.accent)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(pak.name)
                                            .font(.system(size: 13, weight: .semibold))
                                            .lineLimit(1)
                                        Text(pak.sizeText)
                                            .font(.system(size: 10, weight: .medium))
                                            .foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    if importer.importedFiles.contains(pak.name) {
                                        Text("我导入的")
                                            .font(.system(size: 9, weight: .bold))
                                            .foregroundStyle(HomeTheme.accent)
                                            .padding(.horizontal, 7)
                                            .padding(.vertical, 3)
                                            .background(HomeTheme.accent.opacity(0.14), in: Capsule())
                                    }
                                }
                            }
                        } footer: {
                            Text("共 \(importer.gamePaks.count) 个文件 · \(importer.matchedBundleID)")
                        }
                    }
                }
            }
            .navigationTitle("游戏里的包")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("关闭") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("刷新") { importer.refreshGamePaks() }
                }
            }
        }
    }
}

// MARK: - 补丁卡片

private struct PatchOptionCard: View {
    let name: String
    let target: String
    let color: Color
    @Binding var isEnabled: Bool
    let isBusy: Bool
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 11) {
                HStack {
                    Image(systemName: "bolt.fill")
                        .font(.system(size: 15, weight: .bold))
                        .foregroundStyle(color)
                    Spacer()
                    Circle()
                        .fill(isEnabled ? color : Color.white.opacity(0.20))
                        .frame(width: 9, height: 9)
                }
                Text(name)
                    .font(.system(size: 14, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(target)
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
                Text(isEnabled ? "ON" : "OFF")
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .foregroundStyle(isEnabled ? color : Color.white.opacity(0.35))
            }
            .frame(maxWidth: .infinity, minHeight: 142, alignment: .leading)
            .padding(14)
            .background(Color.black.opacity(0.52), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 20, style: .continuous).stroke(isEnabled ? color.opacity(0.85) : color.opacity(0.28), lineWidth: isEnabled ? 1.5 : 1))
            .shadow(color: isEnabled ? color.opacity(0.20) : .clear, radius: 12)
        }
        .buttonStyle(.plain)
        .disabled(isBusy)
        .opacity(isBusy ? 0.55 : 1)
        .accessibilityLabel("\(name), \(target), \(isEnabled ? "On" : "Off")")
    }
}

private struct PatchUnlockPrompt: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField("Package password", text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in store.clearUnlockError() }
                    if let errorKey = store.unlockErrorKey {
                        Text(AppLanguage.english.text(errorKey))
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                } footer: {
                    Text("Enter the password once to unlock this OGIOS package on this device.")
                }
            }
            .navigationTitle("Unlock package")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Unlock", action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

struct AnimatedHyperBackdrop: View {
    @State private var animate = false
    var body: some View {
        GeometryReader { proxy in
            ZStack {
                AppTheme.pageBackground
                Circle()
                    .fill(HomeTheme.accent.opacity(0.10))
                    .frame(width: 280, height: 280)
                    .blur(radius: 70)
                    .offset(x: animate ? 120 : -120, y: -proxy.size.height * 0.23)
                Circle()
                    .fill(HomeTheme.blue.opacity(0.10))
                    .frame(width: 260, height: 260)
                    .blur(radius: 80)
                    .offset(x: animate ? -100 : 100, y: proxy.size.height * 0.22)
                GridOverlay()
            }
            .onAppear {
                withAnimation(.easeInOut(duration: 7).repeatForever(autoreverses: true)) { animate = true }
            }
        }
    }
}

private struct GridOverlay: View {
    var body: some View {
        Canvas { context, size in
            var path = Path()
            let spacing: CGFloat = 44
            stride(from: CGFloat(0), through: size.width, by: spacing).forEach { x in
                path.move(to: CGPoint(x: x, y: 0)); path.addLine(to: CGPoint(x: x, y: size.height))
            }
            stride(from: CGFloat(0), through: size.height, by: spacing).forEach { y in
                path.move(to: CGPoint(x: 0, y: y)); path.addLine(to: CGPoint(x: size.width, y: y))
            }
            context.stroke(path, with: .color(HomeTheme.accent.opacity(0.05)), lineWidth: 1)
        }
    }
}

// MARK: - 文件选择器

struct PakDocumentPicker: UIViewControllerRepresentable {
    var onPick: ([URL]) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let pakType = UTType(filenameExtension: "pak") ?? UTType.data
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: [pakType, .data], asCopy: true)
        picker.allowsMultipleSelection = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        private let onPick: ([URL]) -> Void

        init(onPick: @escaping ([URL]) -> Void) {
            self.onPick = onPick
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            onPick(urls)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {}
    }
}

// MARK: - 和平精英 Paks 一键导入 / 删除

struct GamePak: Identifiable, Equatable {
    let id: String
    let name: String
    let size: Int64

    var sizeText: String {
        if size >= 1_048_576 {
            return String(format: "%.1f MB", Double(size) / 1_048_576.0)
        }
        if size >= 1024 {
            return String(format: "%.0f KB", Double(size) / 1024.0)
        }
        return "\(size) B"
    }
}

// MARK: - 导入 / 修复 结果弹窗

struct PaksAlert: Identifiable {
    let id = UUID()
    let title: String
    let message: String
    var success: Bool = true
}

final class PaksImporter: ObservableObject {
    static let shared = PaksImporter()

    @Published var inboxFiles: [String] = []
    @Published var importedFiles: [String] = []
    @Published var gamePaks: [GamePak] = []
    @Published var busy = false
    @Published var statusText = "待机"
    @Published var containerFound = false
    @Published var matchedBundleID = ""
    @Published var paksCount = 0
    @Published var lastResult = ""
    @Published var pendingAlert: PaksAlert?
    @Published var backupEnabled = true
    @Published var wipeBackupEnabled = true

    private let fm = FileManager.default
    private static let recordFileName = "imported-paks.json"
    private static let inboxFolderName = "PakInbox"
    private static let backupFolderName = "PakBackup"
    private static let backupKey = "ls.paks.backup"
    private static let wipeBackupKey = "ls.paks.wipebackup"

    private init() {
        let defaults = UserDefaults.standard
        if defaults.object(forKey: Self.backupKey) != nil {
            backupEnabled = defaults.bool(forKey: Self.backupKey)
        }
        if defaults.object(forKey: Self.wipeBackupKey) != nil {
            wipeBackupEnabled = defaults.bool(forKey: Self.wipeBackupKey)
        }
    }

    // MARK: - 弹窗控制（自绘浮层）

    func dismissAlert() {
        pendingAlert = nil
    }

    func showAlert(_ title: String, _ message: String, success: Bool = true) {
        DispatchQueue.main.async {
            self.pendingAlert = PaksAlert(title: title, message: message, success: success)
            UINotificationFeedbackGenerator().notificationOccurred(success ? .success : .warning)
        }
    }

    private static var documentsURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
    }

    private static var recordsURL: URL {
        documentsURL.appendingPathComponent(recordFileName)
    }

    private static var inboxURL: URL {
        documentsURL.appendingPathComponent(inboxFolderName, isDirectory: true)
    }

    private static var backupURL: URL {
        documentsURL.appendingPathComponent(backupFolderName, isDirectory: true)
    }

    // 和平精英各服包名，按顺序试
    private static let candidateBundleIDs: [String] = [
        "com.tencent.tmgp.pubgmhd",
        "com.tencent.tmgp.pubgm",
        "com.tencent.ig",
        "com.rekoo.pubgm",
        "com.pubg.krmobile",
        "com.vng.pubgmobile",
        "com.tencent.tmgp.pubgmhd.dev"
    ]

    // MARK: - 开关

    func setBackup(_ on: Bool) {
        backupEnabled = on
        UserDefaults.standard.set(on, forKey: Self.backupKey)
    }

    func setWipeBackup(_ on: Bool) {
        wipeBackupEnabled = on
        UserDefaults.standard.set(on, forKey: Self.wipeBackupKey)
    }

    // MARK: - 外部递进来的文件（文件 App → 打开方式 / 共享）

    static func handles(_ url: URL) -> Bool {
        let ext = url.pathExtension.lowercased()
        return ext == "pak" || ext == "sig"
    }

    func ingestExternal(url: URL) {
        log("external: 收到文件 App 递进来的 \(url.lastPathComponent)")
        add(urls: [url])
        lastResult = "文件 App 递进来 \(url.lastPathComponent)，已放进「待导入」"
        statusText = lastResult
    }

    // MARK: - 状态刷新

    func refresh() {
        DispatchQueue.global(qos: .userInitiated).async {
            let names = self.scanPakFiles()
            let records = self.loadRecords()
            let container = self.resolveContainer()
            var count = 0
            var paks: [GamePak] = []
            if let container = container {
                let paksPath = self.paksPath(for: container.path)
                let handle = ContainerStore.grantContainerAccess(container.path)
                paks = self.listGamePaks(at: paksPath)
                count = paks.count
                if handle >= 0 { bad_query_release(handle) }
            }
            DispatchQueue.main.async {
                self.inboxFiles = names
                self.importedFiles = records
                self.containerFound = container != nil
                self.matchedBundleID = container?.id ?? ""
                self.paksCount = count
                self.gamePaks = paks
            }
        }
    }

    func refreshGamePaks() {
        DispatchQueue.global(qos: .userInitiated).async {
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.containerFound = false
                    self.gamePaks = []
                    self.paksCount = 0
                    self.lastResult = "没定位到游戏容器：先点「⚡ 一键激活内核」，或者先启动一次游戏。"
                }
                return
            }
            let path = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            let paks = self.listGamePaks(at: path)
            if handle >= 0 { bad_query_release(handle) }
            log("paks: 扫描游戏 Paks，找到 \(paks.count) 个文件")
            DispatchQueue.main.async {
                self.containerFound = true
                self.matchedBundleID = container.id
                self.gamePaks = paks
                self.paksCount = paks.count
                self.lastResult = "游戏 Paks 里现在有 \(paks.count) 个文件"
            }
        }
    }

    // MARK: - 低系统档：不碰内核，直接验能不能写进游戏 Paks

    func probeGameWriteAccess() -> (ok: Bool, message: String) {
        guard let container = resolveContainer() else {
            return (false, "没定位到游戏容器，先打开一次游戏再回来点这个按钮。")
        }
        let paks = paksPath(for: container.path)
        let handle = ContainerStore.grantContainerAccess(container.path)
        defer { if handle >= 0 { bad_query_release(handle) } }

        if !fm.fileExists(atPath: paks) {
            do {
                try fm.createDirectory(atPath: paks, withIntermediateDirectories: true)
            } catch {
                return (false, "Paks 目录不存在，也建不出来（\(error.localizedDescription)）。")
            }
        }

        let probe = paks + "/.ls_probe_\(Int(Date().timeIntervalSince1970)).tmp"
        do {
            try Data("ls".utf8).write(to: URL(fileURLWithPath: probe))
            try? fm.removeItem(atPath: probe)
            return (true, "游戏 Paks 可读写，这档不用跑内核。")
        } catch {
            return (false, "游戏 Paks 写不进去（\(error.localizedDescription)）。")
        }
    }

    // MARK: - 添加文件

    func add(urls: [URL]) {
        guard !urls.isEmpty else { return }
        try? fm.createDirectory(at: Self.inboxURL, withIntermediateDirectories: true)
        for url in urls {
            let destination = Self.inboxURL.appendingPathComponent(url.lastPathComponent)
            let scoped = url.startAccessingSecurityScopedResource()
            if fm.fileExists(atPath: destination.path) {
                try? fm.removeItem(at: destination)
            }
            do {
                try fm.copyItem(at: url, to: destination)
                log("paks: 已添加到待导入 \(url.lastPathComponent)")
            } catch {
                log("paks: 添加失败 \(url.lastPathComponent) — \(error.localizedDescription)")
            }
            if scoped { url.stopAccessingSecurityScopedResource() }
        }
        refresh()
        statusText = "已添加到 App"
    }

    // MARK: - 一键导入（覆盖原件）

    func importAll() {
        guard !busy else { return }
        let files = inboxFiles
        guard !files.isEmpty else {
            statusText = "先添加 pak 文件"
            lastResult = "待导入是空的：先点「检查更新」从云端拉最新包，下载完再点「注入」。"
            showAlert(
                "还没有下载新包",
                "待导入列表现在是空的。先点「检查更新」把最新的 pak / sig 拉到 App 里，下载完再点「注入」。",
                success: false
            )
            return
        }
        busy = true
        statusText = "正在导入…"
        lastResult = ""

        DispatchQueue.global(qos: .userInitiated).async {
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.busy = false
                    self.statusText = "没找到和平精英"
                    self.lastResult = "没定位到游戏容器：先点「⚡ 一键激活内核」，或打开一次游戏再回来刷新。"
                    self.showAlert(
                        "注入失败",
                        "没定位到和平精英的游戏目录。先点上面的「⚡ 一键激活内核」，或者打开一次游戏再回来点「注入」。",
                        success: false
                    )
                }
                log("paks: 容器解析失败")
                return
            }

            let paks = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            if !self.fm.fileExists(atPath: paks) {
                do {
                    try self.fm.createDirectory(atPath: paks, withIntermediateDirectories: true)
                } catch {
                    log("paks: 创建 Paks 目录失败 \(error.localizedDescription)")
                }
            }

            var done: [String] = []
            var failed: [String] = []
            for name in files {
                guard let source = self.findFile(named: name) else {
                    failed.append(name)
                    continue
                }
                let destination = paks + "/" + name
                if self.backupEnabled {
                    self.backupOriginal(at: destination, name: name)
                }
                do {
                    try self.installCopy(from: source, to: destination)
                    done.append(name)
                    log("paks: 已覆盖 \(name)")
                } catch {
                    failed.append(name)
                    log("paks: 导入失败 \(name) — \(error.localizedDescription)")
                }
            }

            if handle >= 0 { bad_query_release(handle) }

            var records = self.loadRecords()
            for name in done where !records.contains(name) {
                records.append(name)
            }
            self.saveRecords(records)

            let summary: String
            if done.isEmpty {
                summary = "一个都没导进去（失败 \(failed.count) 个）"
            } else if failed.isEmpty {
                summary = "已导入 \(done.count) 个，游戏里的原件已覆盖"
            } else {
                summary = "注入 \(done.count) 个，失败 \(failed.count) 个"
            }

            DispatchQueue.main.async {
                self.busy = false
                self.statusText = summary
                self.lastResult = failed.isEmpty ? summary : summary + "｜失败：" + failed.joined(separator: "、")
                self.importedFiles = records
                if !done.isEmpty {
                    CloudUpdater.shared.commitAfterImport()
                    if failed.isEmpty {
                        self.showAlert(
                            "注入成功",
                            "已导入 \(done.count) 个文件，游戏里的原件已经覆盖，进游戏就是新内容。"
                        )
                    } else {
                        self.showAlert(
                            "注入完成，有失败",
                            "已导入 \(done.count) 个，\(failed.count) 个没成功：\n" + failed.joined(separator: "、") + "\n\n没成功的可以再点一次「注入」重试。",
                            success: false
                        )
                    }
                } else {
                    self.showAlert(
                        "注入失败",
                        "一个都没导进去（失败 \(failed.count) 个）：\n" + failed.joined(separator: "、") + "\n\n先确认「⚡ 一键激活内核」是已激活，再点一次「注入」。",
                        success: false
                    )
                }
                self.refresh()
            }
        }
    }

    // MARK: - 一键修复（直接删掉导入的文件，不还原原件）

    func deleteImported() {
        guard !busy else { return }
        let names = importedFiles
        guard !names.isEmpty else {
            statusText = "还没有导入记录"
            lastResult = "还没导入过东西：先点「注入」。"
            showAlert(
                "没有可修复的文件",
                "现在还没有导入记录，没有东西可以删。先点「注入」，导进去之后再点「修复」，就会把导进去的文件从游戏里直接删掉。",
                success: false
            )
            return
        }
        busy = true
        statusText = "正在修复…"
        lastResult = ""

        DispatchQueue.global(qos: .userInitiated).async {
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.busy = false
                    self.statusText = "没找到和平精英"
                    self.lastResult = "没定位到游戏容器：先点「⚡ 一键激活内核」，或打开一次游戏再回来刷新。"
                    self.showAlert(
                        "修复失败",
                        "没定位到和平精英的游戏目录。先点上面的「⚡ 一键激活内核」，或者打开一次游戏再回来点「修复」。",
                        success: false
                    )
                }
                return
            }

            let paks = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            var removed: [String] = []
            var failed: [String] = []

            for name in names {
                let path = paks + "/" + name
                var succeeded = false
                if self.fm.fileExists(atPath: path) {
                    do {
                        try self.fm.removeItem(atPath: path)
                        removed.append(name)
                        succeeded = true
                        log("paks: 已从游戏里删除 \(name)")
                    } catch {
                        failed.append(name)
                        log("paks: 删除失败 \(name) — \(error.localizedDescription)")
                    }
                } else {
                    removed.append(name)
                    succeeded = true
                }

                if succeeded && self.wipeBackupEnabled {
                    self.deleteBackup(name: name)
                }
            }

            if handle >= 0 { bad_query_release(handle) }

            let keep = names.filter { !removed.contains($0) }
            self.saveRecords(keep)

            let summary = failed.isEmpty
                ? "已把 \(removed.count) 个文件从游戏里删掉"
                : "删掉 \(removed.count) 个，失败 \(failed.count) 个"

            DispatchQueue.main.async {
                self.busy = false
                self.statusText = summary
                self.lastResult = failed.isEmpty ? summary : summary + "｜失败：" + failed.joined(separator: "、")
                self.importedFiles = keep
                if !removed.isEmpty {
                    if failed.isEmpty {
                        self.showAlert(
                            "修复成功",
                            "已把 \(removed.count) 个文件从游戏里直接删掉，没有还原原件，游戏里现在没有这些文件了。"
                        )
                    } else {
                        self.showAlert(
                            "修复完成，有失败",
                            "已删掉 \(removed.count) 个，\(failed.count) 个没删成功：\n" + failed.joined(separator: "、"),
                            success: false
                        )
                    }
                } else {
                    self.showAlert(
                        "修复失败",
                        "一个都没删掉（失败 \(failed.count) 个）：\n" + failed.joined(separator: "、") + "\n\n先确认「⚡ 一键激活内核」是已激活，再点一次「修复」。",
                        success: false
                    )
                }
                self.refresh()
            }
        }
    }

    // MARK: - 认领 / 清记录

    func claimImported() {
        DispatchQueue.global(qos: .userInitiated).async {
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.lastResult = "没定位到游戏目录，先激活内核。"
                }
                return
            }
            let paks = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            let inside = Set(self.listGamePaks(at: paks).map { $0.name })
            if handle >= 0 { bad_query_release(handle) }

            let inbox = Set(self.scanPakFiles())
            var records = self.loadRecords()
            var added: [String] = []
            for name in inside where inbox.contains(name) && !records.contains(name) {
                records.append(name)
                added.append(name)
            }
            self.saveRecords(records)
            log("paks: 认领 \(added.count) 个已导入文件")

            DispatchQueue.main.async {
                self.importedFiles = records
                self.lastResult = added.isEmpty
                    ? "没有可认领的（游戏里没有和待导入同名的包）"
                    : "认领了 \(added.count) 个：" + added.joined(separator: "、")
                self.refresh()
            }
        }
    }

    func clearStaleRecords() {
        DispatchQueue.global(qos: .userInitiated).async {
            let records = self.loadRecords()
            guard let container = self.resolveContainer() else {
                DispatchQueue.main.async {
                    self.lastResult = "没定位到游戏目录，先激活内核。"
                }
                return
            }
            let paks = self.paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            let inside = Set(self.listGamePaks(at: paks).map { $0.name })
            if handle >= 0 { bad_query_release(handle) }

            let keep = records.filter { inside.contains($0) }
            let dropped = records.count - keep.count
            self.saveRecords(keep)
            log("paks: 清掉 \(dropped) 条失效记录")

            DispatchQueue.main.async {
                self.importedFiles = keep
                self.lastResult = dropped == 0 ? "没有失效记录" : "清掉了 \(dropped) 条失效记录"
                self.refresh()
            }
        }
    }

    // MARK: - 内部

    private func paksPath(for container: String) -> String {
        container + "/Documents/ShadowTrackerExtra/Saved/Paks"
    }

    private func listGamePaks(at path: String) -> [GamePak] {
        guard let names = try? fm.contentsOfDirectory(atPath: path) else { return [] }
        var list: [GamePak] = []
        for name in names {
            let lowered = name.lowercased()
            guard lowered.hasSuffix(".pak") || lowered.hasSuffix(".sig") else { continue }
            let full = path + "/" + name
            let attrs = try? fm.attributesOfItem(atPath: full)
            let size = (attrs?[.size] as? NSNumber)?.int64Value ?? 0
            list.append(GamePak(id: name, name: name, size: size))
        }
        return list.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }

    private func backupOriginal(at destination: String, name: String) {
        guard fm.fileExists(atPath: destination) else { return }
        try? fm.createDirectory(at: Self.backupURL, withIntermediateDirectories: true)
        let target = Self.backupURL.appendingPathComponent(name)
        guard !fm.fileExists(atPath: target.path) else { return }
        do {
            try fm.copyItem(atPath: destination, toPath: target.path)
            log("paks: 已备份原件 \(name)")
        } catch {
            log("paks: 备份原件失败 \(name) — \(error.localizedDescription)")
        }
    }

    private func deleteBackup(name: String) {
        let backup = Self.backupURL.appendingPathComponent(name)
        guard fm.fileExists(atPath: backup.path) else { return }
        do {
            try fm.removeItem(at: backup)
            log("paks: 已删掉备份 \(name)")
        } catch {
            log("paks: 删备份失败 \(name) — \(error.localizedDescription)")
        }
    }

    private func resolveContainer() -> (id: String, path: String)? {
        for bundleID in Self.candidateBundleIDs {
            if let path = ContainerStore.resolveAppContainerPath(bundleID: bundleID) {
                return (bundleID, path)
            }
        }

        var enumerationError: NSString?
        let identifiers = MCMEnumerateIdentifiersForClass(2, 4_096, &enumerationError)
        for identifier in identifiers {
            let lowered = identifier.lowercased()
            guard lowered.contains("pubg") || lowered.contains("tmgp") || lowered.contains("rekoo") else { continue }
            if let path = ContainerStore.resolveAppContainerPath(bundleID: identifier) {
                return (identifier, path)
            }
        }

        // 兜底：直接扫容器元数据（MCM 拒绝时走这条）
        let apps = ContainerStore.containersFromFilesystem()
        for app in apps {
            let lowered = app.bundleID.lowercased()
            let isGame = Self.candidateBundleIDs.contains(app.bundleID)
                || lowered.contains("pubg")
                || lowered.contains("tmgp")
                || lowered.contains("rekoo")
            if isGame {
                return (app.bundleID, app.containerPath)
            }
        }
        return nil
    }

    private func scanPakFiles() -> [String] {
        var names: [String] = []
        guard let enumerator = fm.enumerator(
            at: Self.documentsURL,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ) else {
            return names
        }
        for case let url as URL in enumerator {
            let ext = url.pathExtension.lowercased()
            guard ext == "pak" || ext == "sig" else { continue }
            guard !url.path.contains(Self.backupFolderName) else { continue }
            names.append(url.lastPathComponent)
        }
        return Array(Set(names)).sorted()
    }

    private func findFile(named name: String) -> URL? {
        let inbox = Self.inboxURL.appendingPathComponent(name)
        if fm.fileExists(atPath: inbox.path) { return inbox }
        guard let enumerator = fm.enumerator(
            at: Self.documentsURL,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ) else {
            return nil
        }
        for case let url as URL in enumerator where url.lastPathComponent == name {
            guard !url.path.contains(Self.backupFolderName) else { continue }
            return url
        }
        return nil
    }

    private func installCopy(from source: URL, to destination: String) throws {
        let temporary = destination + ".tmp-" + String(UUID().uuidString.prefix(8))
        if fm.fileExists(atPath: temporary) {
            try? fm.removeItem(atPath: temporary)
        }
        do {
            try fm.copyItem(at: source, to: URL(fileURLWithPath: temporary))
        } catch {
            // 临时文件占双倍空间，空间紧时退回「先腾位再直写」
            if fm.fileExists(atPath: destination) {
                try? fm.removeItem(atPath: destination)
            }
            try fm.copyItem(at: source, to: URL(fileURLWithPath: destination))
            return
        }

        if fm.fileExists(atPath: destination) {
            do {
                _ = try fm.replaceItemAt(
                    URL(fileURLWithPath: destination),
                    withItemAt: URL(fileURLWithPath: temporary),
                    backupItemName: nil,
                    options: []
                )
                return
            } catch {
                try? fm.removeItem(atPath: destination)
            }
        }
        try fm.moveItem(atPath: temporary, toPath: destination)
    }

    private func loadRecords() -> [String] {
        guard let data = try? Data(contentsOf: Self.recordsURL),
              let list = try? JSONDecoder().decode([String].self, from: data) else {
            return []
        }
        return list
    }

    private func saveRecords(_ names: [String]) {
        guard let data = try? JSONEncoder().encode(names) else { return }
        try? data.write(to: Self.recordsURL)
    }

    /// 云端更新用：把「上一版有、这一版没有」的旧包，从游戏 Paks 和待导入区一起清掉
    func removeFromGameAndInbox(names: [String]) -> [String] {
        guard !names.isEmpty else { return [] }
        var removed: [String] = []

        if let container = resolveContainer() {
            let paks = paksPath(for: container.path)
            let handle = ContainerStore.grantContainerAccess(container.path)
            for name in names {
                let path = paks + "/" + name
                if fm.fileExists(atPath: path) {
                    do {
                        try fm.removeItem(atPath: path)
                        removed.append(name)
                        log("cloud: 已清掉旧包 \(name)")
                    } catch {
                        log("cloud: 旧包删不掉 \(name) — \(error.localizedDescription)")
                    }
                }
            }
            if handle >= 0 { bad_query_release(handle) }
        }

        for name in names {
            try? fm.removeItem(at: Self.inboxURL.appendingPathComponent(name))
        }

        if !removed.isEmpty {
            let records = loadRecords().filter { !removed.contains($0) }
            saveRecords(records)
            DispatchQueue.main.async { self.importedFiles = records }
        }
        return removed
    }
}

// MARK: - 一页版 · 首页（浪神文件管理器）

/// 两个版本档：低系统 / 高系统。区间就是巨魔能装的边界。
enum PakTier: String, CaseIterable {
    case low
    case high

    var title: String {
        switch self {
        case .low: return "低系统版本"
        case .high: return "高系统版本"
        }
    }

    var range: String {
        switch self {
        case .low: return "iOS 14.0 – 16.6.1"
        case .high: return "iOS 17.0 – 26.6.2"
        }
    }

    var note: String {
        switch self {
        case .low: return "巨魔直装 · 不碰内核"
        case .high: return "内核自适应 · 现场校准"
        }
    }

    var icon: String {
        switch self {
        case .low: return "shippingbox.fill"
        case .high: return "bolt.shield.fill"
        }
    }
}

enum TierState: Equatable {
    case idle
    case running
    case ok
    case fail

    var text: String {
        switch self {
        case .idle: return "未试"
        case .running: return "检测中"
        case .ok: return "已打通"
        case .fail: return "未通"
        }
    }
}

struct RootGateView: View {
    @EnvironmentObject private var license: LicenseManager

    /// 启动视频是否已经放完（放完才允许进主界面，也让用户先看见那一下）
    @State private var splashDone = false

    var body: some View {
        ZStack {
            if license.isUnlocked && splashDone {
                SimpleHomeView()
                    .transition(.opacity)
            } else {
                SplashLicenseGateView(
                    skipVideo: splashDone,
                    onVideoEnd: {
                        withAnimation(.easeInOut(duration: 0.45)) {
                            splashDone = true
                        }
                    }
                )
                .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.32), value: license.state)
    }
}

// ============================================================
// v1.5.1 · 云端发布 · 用户端「更新完直接点导入」
// 全部代码放在这个文件末尾，不新增工程文件（避免 pbxproj 漏注册）
// ============================================================

struct SimpleHomeView: View {
    @EnvironmentObject private var appState: AppState
    @ObservedObject private var importer = PaksImporter.shared
    @ObservedObject private var cloud = CloudUpdater.shared

    @State private var selectedTier: PakTier = AppInfo.versionTuple.major >= 17 ? .high : .low
    @State private var lowState: TierState = .idle
    @State private var highState: TierState = .idle
    @State private var lowProbing = false

    // v20.0 · 防封这一块的状态
    @State private var guardOn: Bool = (UserDefaults.standard.object(forKey: "ls.guard.on") as? Bool) ?? false
    @State private var guardLevel: LSGuardLevel = .sandbox
    @State private var gameModeOn = false
    @State private var guardLines: [String] = []
    @State private var guardBusy = false
    @State private var guardBootstrapped = false

    // v23.0 · 运行记录直接跑在卡片里（不弹窗），点展开看全部
    @State private var guardExpanded = false
    @State private var guardRunToken = 0
    @State private var toolboxExpanded = false
    @State private var renewCode = ""
    @State private var renewBusy = false
    @State private var guardRecords: [LSGuardRecord] = []
    @State private var guardRealLines: [String] = []
    @State private var guardTotal = 0
    @State private var guardRunCount: Int = (UserDefaults.standard.object(forKey: "ls.guard.runs") as? Int) ?? 0

    private let accent = HomeTheme.accent
    private let danger = Color(red: 0.90, green: 0.31, blue: 0.31)
    private let ticker = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        GeometryReader { geo in
            let wide = geo.size.width >= 700
            let contentMax: CGFloat = wide ? 700 : .infinity
            let sidePad: CGFloat = wide ? 30 : (geo.size.width < 375 ? 14 : 18)
            ZStack {
                HomeBackdrop()

                ScrollView(showsIndicators: false) {
                    VStack(spacing: wide ? 16 : 14) {
                        header
                        statusRow
                        expiryBar
                        antiBanCard
                        tierRow
                        cloudCard
                        actionRow
                        gameRow
                        quickRow
                        listCard
                        toolboxCard
                        renewCard
                        resultLine
                    }
                    .frame(maxWidth: contentMax)
                    .padding(.horizontal, sidePad)
                    .padding(.top, wide ? 34 : 26)
                    .padding(.bottom, 40)
                    .frame(maxWidth: .infinity)
                }
            }
        }
        .preferredColorScheme(.dark)
        .onAppear {
            importer.refresh()
            syncStates()
            cloud.autoCheck()
        }
        .onReceive(ticker) { _ in syncStates() }
        .alert(item: $importer.pendingAlert) { item in
            Alert(
                title: Text(item.title),
                message: Text(item.message),
                dismissButton: .default(Text("知道了")) { importer.dismissAlert() }
            )
        }
    }

    // MARK: 顶部（长按标题 → 填发布地址）

    private var header: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack(alignment: .firstTextBaseline, spacing: 8) {
                Text("浪神")
                    .font(.system(size: 28, weight: .black, design: .rounded))
                    .foregroundStyle(
                        LinearGradient(colors: [LSGuardTheme.ice, LSGuardTheme.neon],
                                       startPoint: .topLeading,
                                       endPoint: .bottomTrailing)
                    )
                    .shadow(color: LSGuardTheme.neon.opacity(0.55), radius: 14)
                    .onLongPressGesture(minimumDuration: 1.2) {
                        promptCloudAddress()
                    }
                Spacer(minLength: 0)
                Text(guardLevel == .crossApp ? "跨 App" : "沙盒")
                    .font(.system(size: 10, weight: .black, design: .rounded))
                    .foregroundStyle(LSGuardTheme.neon)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .overlay(
                        LSChamferShape(cut: 5)
                            .stroke(LSGuardTheme.neon.opacity(0.60), lineWidth: 1)
                    )
                Text("v26.0")
                    .font(.system(size: 9, weight: .black, design: .monospaced))
                    .foregroundStyle(LSGuardTheme.ice.opacity(0.85))
                    .padding(.horizontal, 7)
                    .padding(.vertical, 4)
                    .overlay(
                        LSChamferShape(cut: 5)
                            .stroke(LSGuardTheme.ice.opacity(0.32), lineWidth: 1)
                    )
            }
            HStack(spacing: 8) {
                Rectangle()
                    .fill(
                        LinearGradient(colors: [LSGuardTheme.neon.opacity(0.9), LSGuardTheme.neon.opacity(0)],
                                       startPoint: .leading,
                                       endPoint: .trailing)
                    )
                    .frame(height: 1)
                Text("iOS \(AppInfo.osVersion)")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(LSGuardTheme.neon.opacity(0.72))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func promptCloudAddress() {
        let alert = UIAlertController(
            title: "发布地址",
            message: "填你自己的发布服务地址，末尾不要带斜杠。留空 = 用内置地址。",
            preferredStyle: .alert
        )
        alert.addTextField { tf in
            tf.placeholder = "https://你的域名"
            tf.text = CloudConfig.isCustom ? CloudConfig.base : ""
            tf.keyboardType = .URL
            tf.autocapitalizationType = .none
            tf.autocorrectionType = .no
            tf.clearButtonMode = .whileEditing
        }
        alert.addAction(UIAlertAction(title: "取消", style: .cancel))
        alert.addAction(UIAlertAction(title: "保存", style: .default) { _ in
            CloudConfig.setBase(alert.textFields?.first?.text ?? "")
            CloudUpdater.shared.reset()
            CloudUpdater.shared.check(manual: true)
        })
        presentOnTop(alert)
    }

    private func presentOnTop(_ vc: UIViewController) {
        guard let scene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let root = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController else { return }
        var top = root
        while let presented = top.presentedViewController { top = presented }
        top.present(vc, animated: true)
    }

    // MARK: 状态

    private var statusRow: some View {
        HStack(spacing: 10) {
            tag(selectedTier == .low ? "当前档：低系统" : "当前档：高系统",
                color: accent)
            tag(importer.containerFound ? "游戏目录已找到" : "游戏目录未找到",
                color: importer.containerFound ? accent : Color.white.opacity(0.5))
            Spacer(minLength: 0)
        }
    }

    private func tag(_ text: String, color: Color) -> some View {
        HStack(spacing: 6) {
            Circle().fill(color).frame(width: 7, height: 7)
            Text(text)
                .font(.system(size: 11, weight: .bold, design: .rounded))
                .foregroundStyle(color)
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 6))
        .overlay(LSChamferShape(cut: 6).stroke(color.opacity(0.28), lineWidth: 1))
    }

    // MARK: 到期时间（v23.0 · 一眼能看到还剩几天）

    private var expiryBar: some View {
        let days = license.remainingDays
        let expired = license.state == .expired || ((days ?? 0) < 0)
        let tone = expired ? danger : LSGuardTheme.neon
        let forever = license.isPermanent
        return HStack(spacing: 10) {
            Image(systemName: forever ? "infinity" : (expired ? "lock.fill" : "calendar"))
                .font(.system(size: 13, weight: .bold))
                .foregroundStyle(tone)
                .frame(width: 20)
            VStack(alignment: .leading, spacing: 1) {
                Text(expired ? "卡密已到期" : "到期时间")
                    .font(.system(size: 9.5, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.42))
                Text(license.expiryLabel)
                    .font(.system(size: 13, weight: .black, design: .monospaced))
                    .foregroundStyle(.white)
            }
            Spacer(minLength: 6)
            Text(daysText(days, expired: expired, forever: forever))
                .font(.system(size: 10, weight: .black, design: .rounded))
                .foregroundStyle(tone)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(tone.opacity(0.13), in: LSChamferShape(cut: 5))
                .overlay(LSChamferShape(cut: 5).stroke(tone.opacity(0.34), lineWidth: 1))
        }
        .padding(.horizontal, 13)
        .padding(.vertical, 10)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 12))
        .overlay(LSChamferShape(cut: 12).stroke(tone.opacity(0.30), lineWidth: 1.1))
    }

    private func daysText(_ days: Int?, expired: Bool, forever: Bool) -> String {
        if forever { return "长期" }
        guard let days else { return "—" }
        if expired || days < 0 { return "已过期 " + String(abs(days)) + " 天" }
        if days == 0 { return "今天到期" }
        return "剩 " + String(days) + " 天"
    }

    // MARK: 两个系统版本按钮（首屏主角）

    private var tierRow: some View {
        HStack(spacing: 12) {
            tierButton(.low, state: lowState)
            tierButton(.high, state: highState)
        }
    }

    private func tierButton(_ tier: PakTier, state: TierState) -> some View {
        let on = selectedTier == tier
        let tone = stateColor(state, fallback: on ? accent : Color.white.opacity(0.45))

        return Button {
            select(tier)
        } label: {
            VStack(alignment: .leading, spacing: 6) {
                HStack(spacing: 6) {
                    Image(systemName: tier.icon)
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(tone)
                    Spacer(minLength: 0)
                    HStack(spacing: 5) {
                        Circle().fill(tone).frame(width: 6, height: 6)
                        Text(state.text)
                            .font(.system(size: 10, weight: .bold, design: .rounded))
                            .foregroundStyle(tone)
                    }
                }
                Text(tier.title)
                    .font(.system(size: 18, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(tier.range)
                    .font(.system(size: 13, weight: .heavy, design: .rounded))
                    .foregroundStyle(tone)
                Text(tier.note)
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.45))
            }
            .frame(maxWidth: .infinity, minHeight: 104, alignment: .leading)
            .padding(13)
            .background(
                (on ? tone.opacity(0.16) : LSGuardTheme.panel),
                in: LSChamferShape(cut: 16)
            )
            .overlay(
                LSChamferShape(cut: 16)
                    .stroke(tone.opacity(on ? 0.95 : 0.34), lineWidth: on ? 2 : 1.2)
            )
            .shadow(color: on ? tone.opacity(0.30) : Color.clear, radius: 16)
        }
        .buttonStyle(.plain)
        .disabled(state == .running)
    }

    private func stateColor(_ state: TierState, fallback: Color) -> Color {
        switch state {
        case .idle: return fallback
        case .running: return HomeTheme.yellow
        case .ok: return accent
        case .fail: return danger
        }
    }

    // MARK: 选档 + 按这档跑

    private func select(_ tier: PakTier) {
        selectedTier = tier
        switch tier {
        case .low:
            runLowTier()
        case .high:
            runHighTier()
        }
    }

    /// 低系统档：14.0–16.6.1 有巨魔环境，本身就带写权限，不碰内核，只验能不能真写进游戏 Paks。
    private func runLowTier() {
        guard !lowProbing else { return }
        lowProbing = true
        lowState = .running
        importer.lastResult = "低系统档：正在验游戏 Paks 能不能写…"

        DispatchQueue.global(qos: .userInitiated).async {
            let result = PaksImporter.shared.probeGameWriteAccess()
            DispatchQueue.main.async {
                lowProbing = false
                lowState = result.ok ? .ok : .fail
                importer.lastResult = "低系统档：" + result.message
                importer.refresh()
            }
        }
    }

    /// 高系统档：17.0–26.6.2 走内核链，偏移按本机现场校准。
    private func runHighTier() {
        if appState.kernelExploitRunning { return }
        highState = .running
        appState.runKernelExploitIfNeeded()
    }

    private func syncStates() {
        if appState.kernelExploitRunning {
            if highState != .running { highState = .running }
            return
        }
        if appState.exploitStatus.isSuccess {
            if highState != .ok {
                highState = .ok
                if selectedTier == .high {
                    importer.lastResult = "高系统档已打通：内核通，游戏目录可读写。"
                }
            }
        } else if appState.exploitStatus.isFailed {
            if highState == .running {
                highState = .fail
                if selectedTier == .high {
                    importer.lastResult = "高系统档没打通：内核没进去，点一下再看日志，或重启 App 再试。"
                }
            }
        }
    }

    // MARK: 云端卡片（有新版本才显得出来）

    private var cloudIcon: String {
        switch cloud.phase {
        case .available: return "arrow.down.circle.fill"
        case .downloading: return "arrow.down.circle"
        case .ready: return "checkmark.circle.fill"
        case .upToDate: return "checkmark.seal.fill"
        case .failed: return "exclamationmark.triangle.fill"
        default: return "icloud"
        }
    }

    private var cloudTint: Color {
        switch cloud.phase {
        case .available: return HomeTheme.yellow
        case .downloading: return HomeTheme.yellow
        case .ready: return accent
        case .upToDate: return accent
        case .failed: return danger
        default: return Color.white.opacity(0.5)
        }
    }

    private var cloudTitle: String {
        switch cloud.phase {
        case .available: return "发现新版本 " + (cloud.remote?.version ?? "")
        case .downloading: return "正在下载新包"
        case .ready: return "新包已就绪 " + (cloud.pending?.version ?? "")
        case .upToDate: return cloud.installedVersion.isEmpty ? "云端已就绪" : "云端已是最新 " + cloud.installedVersion
        case .checking: return "正在检查更新"
        case .failed: return "云端连不上"
        default: return "云端"
        }
    }

    private var cloudCard: some View {
        let tint = cloudTint
        return VStack(alignment: .leading, spacing: 9) {
            HStack(spacing: 8) {
                Image(systemName: cloudIcon)
                    .font(.system(size: 13, weight: .bold))
                    .foregroundStyle(tint)
                Text(cloudTitle)
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                    .minimumScaleFactor(0.8)
                Spacer(minLength: 0)
                Text(cloud.phase.text)
                    .font(.system(size: 10, weight: .bold, design: .rounded))
                    .foregroundStyle(tint)
                    .padding(.horizontal, 7)
                    .padding(.vertical, 3)
                    .background(tint.opacity(0.16), in: Capsule())
            }

            if cloud.phase == .downloading {
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule().fill(Color.white.opacity(0.1))
                        Capsule().fill(tint)
                            .frame(width: max(6, geo.size.width * CGFloat(max(0, min(1, cloud.progress)))))
                    }
                }
                .frame(height: 6)
            }

            Text(cloud.line)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.white.opacity(0.6))
                .fixedSize(horizontal: false, vertical: true)

            if !cloud.notesText.isEmpty && (cloud.phase == .available || cloud.phase == .ready) {
                Text(cloud.notesText)
                    .font(.system(size: 11, weight: .semibold))
                    .foregroundStyle(.white.opacity(0.8))
                    .fixedSize(horizontal: false, vertical: true)
            }

            if cloud.phase == .available {
                Button {
                    cloud.update()
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "arrow.down.circle.fill")
                            .font(.system(size: 12, weight: .bold))
                        Text("立即更新")
                            .font(.system(size: 13, weight: .black, design: .rounded))
                    }
                    .foregroundStyle(.black)
                    .frame(maxWidth: .infinity, minHeight: 38)
                    .background(tint, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                }
                .buttonStyle(.plain)
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 14))
        .overlay(
            LSChamferShape(cut: 14)
                .stroke(tint.opacity(0.42), lineWidth: 1.1)
        )
    }

    // MARK: 注入 / 修复

    private var actionRow: some View {
        HStack(spacing: 12) {
            bigButton(title: "注入",
                      subtitle: "把已下载的包写进游戏",
                      icon: "bolt.fill",
                      tint: LSGuardTheme.neon) {
                importer.importAll()
            }
            bigButton(title: "修复",
                      subtitle: "清掉写进去的包，恢复原样",
                      icon: "wrench.and.screwdriver.fill",
                      tint: LSGuardTheme.ice) {
                importer.deleteImported()
            }
        }
    }

    private func bigButton(title: String,
                           subtitle: String,
                           icon: String,
                           tint: Color,
                           action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 8) {
                Image(systemName: icon)
                    .font(.system(size: 20, weight: .bold))
                    .foregroundStyle(tint)
                    .shadow(color: tint.opacity(0.7), radius: 10)
                Text(title)
                    .font(.system(size: 20, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Text(subtitle)
                    .font(.system(size: 10, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.55))
                    .fixedSize(horizontal: false, vertical: true)
            }
            .frame(maxWidth: .infinity, minHeight: 118, alignment: .leading)
            .padding(16)
            .background(
                LinearGradient(colors: [tint.opacity(0.20), LSGuardTheme.panelDeep],
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing),
                in: LSChamferShape(cut: 16)
            )
            .overlay(
                LSChamferShape(cut: 16)
                    .stroke(tint.opacity(0.62), lineWidth: 1.3)
            )
        }
        .buttonStyle(.plain)
        .disabled(importer.busy)
        .opacity(importer.busy ? 0.5 : 1)
    }

    // MARK: 次要按钮

    private var quickRow: some View {
        HStack(spacing: 10) {
            chipButton("检查更新", icon: "icloud.and.arrow.down") {
                CloudUpdater.shared.check(manual: true)
            }
            chipButton("刷新", icon: "arrow.clockwise") { importer.refresh() }
        }
    }

    private func chipButton(_ title: String, icon: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: icon).font(.system(size: 11, weight: .bold))
                Text(title).font(.system(size: 12, weight: .bold, design: .rounded))
            }
            .foregroundStyle(.white.opacity(0.92))
            .frame(maxWidth: .infinity, minHeight: 40)
            .background(LSGuardTheme.panel, in: LSChamferShape(cut: 10))
            .overlay(LSChamferShape(cut: 10).stroke(LSGuardTheme.neon.opacity(0.26), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    // MARK: 文件清单

    private var listCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("待导入 \(importer.inboxFiles.count) · 已导入 \(importer.importedFiles.count)")
                    .font(.system(size: 12, weight: .bold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.75))
                Spacer()
                if importer.busy {
                    Text("处理中…")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundStyle(HomeTheme.yellow)
                }
            }

            if importer.inboxFiles.isEmpty && importer.importedFiles.isEmpty {
                Text("还没有包。点「检查更新」从云端拉最新包，下载完点「注入」。")
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(.white.opacity(0.45))
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                ForEach(importer.inboxFiles, id: \.self) { name in
                    row(name: name, badge: "待注入", color: HomeTheme.yellow)
                }
                ForEach(importer.importedFiles, id: \.self) { name in
                    row(name: name, badge: "已注入", color: accent)
                }
            }
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 14))
        .overlay(LSChamferShape(cut: 14).stroke(LSGuardTheme.neon.opacity(0.22), lineWidth: 1))
    }

    private func row(name: String, badge: String, color: Color) -> some View {
        HStack(spacing: 8) {
            Image(systemName: "doc.fill")
                .font(.system(size: 11))
                .foregroundStyle(color.opacity(0.9))
            Text(name)
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(.white.opacity(0.9))
                .lineLimit(1)
            Spacer(minLength: 6)
            Text(badge)
                .font(.system(size: 9, weight: .bold, design: .rounded))
                .foregroundStyle(color)
                .padding(.horizontal, 6)
                .padding(.vertical, 2)
                .background(color.opacity(0.16), in: Capsule())
        }
    }

    // MARK: 结果

    private var resultLine: some View {
        Text(importer.lastResult.isEmpty ? "就绪" : importer.lastResult)
            .font(.system(size: 11, weight: .medium))
            .foregroundStyle(.white.opacity(0.55))
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    // MARK: - v20.0 · 防封模式（跟工具箱同一块，都在这一页里）

    private var antiBanCard: some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack(spacing: 8) {
                Text("🛡").font(.system(size: 16))
                Text("防封模式")
                    .font(.system(size: 15, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Spacer(minLength: 0)
                HStack(spacing: 6) {
                    Circle()
                        .fill(guardBusy ? HomeTheme.yellow : LSGuardTheme.neon)
                        .frame(width: 6, height: 6)
                    Text(guardBusy ? "运行中" : (guardOn ? "已开启" : "未开启"))
                        .font(.system(size: 11, weight: .black, design: .rounded))
                        .foregroundStyle(guardBusy ? HomeTheme.yellow : LSGuardTheme.neon)
                }
                .padding(.horizontal, 9)
                .padding(.vertical, 5)
                .background(LSGuardTheme.neon.opacity(0.12), in: LSChamferShape(cut: 5))
                .overlay(LSChamferShape(cut: 5)
                    .stroke(LSGuardTheme.neon.opacity(0.55), lineWidth: 1))
            }

            HStack(spacing: 8) {
                guardTag(guardLevel.title,
                         color: guardLevel == .crossApp ? LSGuardTheme.neon : LSGuardTheme.dim)
                guardTag("累计启动 " + String(guardRunCount) + " 次",
                         color: guardRunCount > 0 ? LSGuardTheme.ice : LSGuardTheme.dim)
                Spacer(minLength: 0)
            }

            Text(guardLevel.detail)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.white.opacity(0.66))
                .fixedSize(horizontal: false, vertical: true)

            Button {
                fireGuard()
            } label: {
                HStack(spacing: 8) {
                    Image(systemName: guardBusy ? "hourglass" : "shield.lefthalf.filled")
                        .font(.system(size: 13, weight: .black))
                    Text(guardBusy ? "正在跑…" : "开启防封")
                        .font(.system(size: 14, weight: .black, design: .rounded))
                    Spacer(minLength: 0)
                    Text(guardTotal > 0 ? String(guardRecords.count) + "/" + String(guardTotal) : (guardBusy ? "…" : "就绪"))
                        .font(.system(size: 10, weight: .black, design: .monospaced))
                        .opacity(0.72)
                }
                .foregroundStyle(.black)
                .padding(.horizontal, 14)
                .frame(maxWidth: .infinity, minHeight: 46)
                .background(
                    LinearGradient(colors: [LSGuardTheme.neon, LSGuardTheme.ice],
                                   startPoint: .leading,
                                   endPoint: .trailing),
                    in: LSChamferShape(cut: 10)
                )
            }
            .buttonStyle(.plain)
            .disabled(guardBusy)
            .opacity(guardBusy ? 0.55 : 1)

            Rectangle()
                .fill(LSGuardTheme.neon.opacity(0.18))
                .frame(height: 1)
                .padding(.vertical, 1)

            guardRecordsBlock
        }
        .padding(15)
        .background(
            LinearGradient(colors: [LSGuardTheme.neon.opacity(guardOn ? 0.16 : 0.08),
                                    LSGuardTheme.panelDeep],
                           startPoint: .topLeading,
                           endPoint: .bottomTrailing),
            in: LSChamferShape(cut: 14)
        )
        .overlay(LSChamferShape(cut: 14)
            .stroke(LSGuardTheme.neon.opacity(guardOn ? 0.85 : 0.40), lineWidth: 1.3))
        .shadow(color: LSGuardTheme.neon.opacity(guardOn ? 0.28 : 0), radius: 18)
        .onAppear { refreshGuardLevel() }
    }

    /// 运行记录：默认只露最近 3 条，点右边的展开图标才铺开全部
    private var guardRecordsBlock: some View {
        VStack(alignment: .leading, spacing: 8) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { guardExpanded.toggle() }
            } label: {
                HStack(spacing: 7) {
                    Image(systemName: "list.bullet.rectangle")
                        .font(.system(size: 11, weight: .bold))
                    Text("运行记录")
                        .font(.system(size: 12, weight: .black, design: .rounded))
                    if guardTotal > 0 {
                        Text(String(guardRecords.count) + "/" + String(guardTotal))
                            .font(.system(size: 10, weight: .black, design: .monospaced))
                            .foregroundStyle(LSGuardTheme.neon.opacity(0.9))
                    }
                    Spacer(minLength: 0)
                    Text(guardRecords.isEmpty ? "未运行" : (guardExpanded ? "收起" : "展开"))
                        .font(.system(size: 10.5, weight: .bold, design: .rounded))
                    Image(systemName: guardExpanded ? "chevron.up.circle.fill" : "chevron.down.circle.fill")
                        .font(.system(size: 16, weight: .bold))
                }
                .foregroundStyle(LSGuardTheme.neon.opacity(0.92))
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if guardRecords.isEmpty {
                Text("点上面的「开启防封」，机制会一条一条跑在这里。")
                    .font(.system(size: 10.5, weight: .medium))
                    .foregroundStyle(.white.opacity(0.42))
                    .frame(maxWidth: .infinity, alignment: .leading)
            } else {
                if guardBusy {
                    GeometryReader { g in
                        ZStack(alignment: .leading) {
                            Capsule().fill(Color.white.opacity(0.1))
                            Capsule().fill(LSGuardTheme.neon)
                                .frame(width: max(6, g.size.width * CGFloat(Double(guardRecords.count) / Double(max(guardTotal, 1)))))
                        }
                    }
                    .frame(height: 4)
                }

                if guardExpanded {
                    ScrollViewReader { proxy in
                        ScrollView(showsIndicators: false) {
                            VStack(alignment: .leading, spacing: 8) {
                                ForEach(guardRecords) { rec in
                                    guardRecordRow(rec).id(rec.id)
                                }
                                if !guardBusy {
                                    guardCleanupBlock
                                }
                            }
                            .padding(.vertical, 1)
                        }
                        .frame(height: 236)
                        .onChange(of: guardRecords.count) { _ in
                            if let last = guardRecords.last {
                                withAnimation(.easeOut(duration: 0.18)) {
                                    proxy.scrollTo(last.id, anchor: .bottom)
                                }
                            }
                        }
                    }
                } else {
                    ForEach(guardRecords.suffix(3)) { rec in
                        guardRecordRow(rec)
                    }
                }
            }
        }
    }

    private func guardRecordRow(_ rec: LSGuardRecord) -> some View {
        HStack(alignment: .top, spacing: 7) {
            Text(rec.icon)
                .font(.system(size: 10))
                .frame(width: 14, alignment: .center)
            Text(rec.text)
                .font(.system(size: 11, weight: .semibold, design: .rounded))
                .foregroundStyle(.white.opacity(0.90))
                .fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 4)
            if rec.cost > 0 {
                Text(String(rec.cost) + " ms")
                    .font(.system(size: 9, weight: .bold, design: .monospaced))
                    .foregroundStyle(LSGuardTheme.neon.opacity(0.55))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var guardCleanupBlock: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text("顺手清掉的")
                .font(.system(size: 9.5, weight: .bold, design: .rounded))
                .foregroundStyle(.white.opacity(0.32))
                .padding(.top, 4)
            ForEach(Array(guardRealLines.suffix(6).enumerated()), id: \.offset) { _, line in
                Text(line)
                    .font(.system(size: 10, weight: .medium, design: .monospaced))
                    .foregroundStyle(.white.opacity(0.52))
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }

    private func guardTag(_ text: String, color: Color) -> some View {
        HStack(spacing: 5) {
            Circle().fill(color).frame(width: 6, height: 6)
            Text(text)
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .foregroundStyle(color)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(color.opacity(0.12), in: LSChamferShape(cut: 5))
        .overlay(LSChamferShape(cut: 5).stroke(color.opacity(0.24), lineWidth: 1))
    }

    private var toolboxCard: some View {
        VStack(alignment: .leading, spacing: 9) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) { toolboxExpanded.toggle() }
            } label: {
                HStack(spacing: 8) {
                    Text("🧰").font(.system(size: 15))
                    Text("防封工具箱")
                        .font(.system(size: 14, weight: .black, design: .rounded))
                        .foregroundStyle(.white)
                    Text(String(LSGuardTool.available(guardLevel).count) + " 项")
                        .font(.system(size: 9.5, weight: .black, design: .monospaced))
                        .foregroundStyle(LSGuardTheme.neon.opacity(0.85))
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(LSGuardTheme.neon.opacity(0.12), in: Capsule())
                    Spacer(minLength: 0)
                    Text(toolboxExpanded ? "收起" : "展开")
                        .font(.system(size: 10.5, weight: .bold, design: .rounded))
                    Image(systemName: toolboxExpanded ? "chevron.up.circle.fill" : "chevron.down.circle.fill")
                        .font(.system(size: 16, weight: .bold))
                }
                .foregroundStyle(LSGuardTheme.neon.opacity(0.92))
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)

            if toolboxExpanded {
                ForEach(LSGuardTool.available(guardLevel)) { item in
                    Button {
                        runGuardTool(item)
                    } label: {
                        HStack(spacing: 10) {
                            Text(item.icon).font(.system(size: 15))
                                .frame(width: 24, height: 24)
                                .background(LSGuardTheme.neon.opacity(0.10), in: LSChamferShape(cut: 6))
                            VStack(alignment: .leading, spacing: 2) {
                                Text(item.title)
                                    .font(.system(size: 12.5, weight: .bold, design: .rounded))
                                    .foregroundStyle(.white.opacity(0.94))
                                Text(item.sub)
                                    .font(.system(size: 10, weight: .medium))
                                    .foregroundStyle(.white.opacity(0.45))
                            }
                            Spacer(minLength: 0)
                            Image(systemName: "chevron.right")
                                .font(.system(size: 10, weight: .bold))
                                .foregroundStyle(LSGuardTheme.neon.opacity(0.75))
                        }
                        .padding(.vertical, 7)
                        .padding(.horizontal, 9)
                        .background(Color.white.opacity(0.03), in: LSChamferShape(cut: 9))
                        .overlay(LSChamferShape(cut: 9).stroke(LSGuardTheme.neon.opacity(0.16), lineWidth: 1))
                    }
                    .buttonStyle(.plain)
                    .disabled(guardBusy)
                    .opacity(guardBusy ? 0.55 : 1)
                }

                if !guardLines.isEmpty {
                    Rectangle()
                        .fill(LSGuardTheme.neon.opacity(0.18))
                        .frame(height: 1)
                        .padding(.vertical, 2)
                    ForEach(Array(guardLines.suffix(8).enumerated()), id: \.offset) { _, line in
                        Text(line)
                            .font(.system(size: 10.5, weight: .medium, design: .monospaced))
                            .foregroundStyle(line.hasPrefix("✓") ? LSGuardTheme.neon.opacity(0.9) : Color.white.opacity(0.6))
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            } else {
                Text(guardBusy ? "执行中…" : "点「展开」看工具箱里的全部功能")
                    .font(.system(size: 10.5, weight: .medium))
                    .foregroundStyle(.white.opacity(0.40))
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(14)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 12))
        .overlay(LSChamferShape(cut: 12).stroke(LSGuardTheme.neon.opacity(0.42), lineWidth: 1.2))
    }

    // MARK: 进入游戏（v23.0 · 直接跳本地和平精英）

    private var gameRow: some View {
        Button {
            openGame()
        } label: {
            HStack(spacing: 9) {
                Image(systemName: "gamecontroller.fill")
                    .font(.system(size: 15, weight: .black))
                Text("进入游戏")
                    .font(.system(size: 15, weight: .black, design: .rounded))
                Spacer(minLength: 0)
                Text(importer.matchedBundleID.isEmpty ? "和平精英" : "和平精英 · 已定位")
                    .font(.system(size: 10.5, weight: .bold, design: .rounded))
                    .opacity(0.72)
                Image(systemName: "arrow.up.forward.app.fill")
                    .font(.system(size: 12, weight: .black))
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 16)
            .frame(maxWidth: .infinity, minHeight: 50)
            .background(
                LinearGradient(colors: [LSGuardTheme.ice.opacity(0.30),
                                        LSGuardTheme.neon.opacity(0.20),
                                        LSGuardTheme.panelDeep],
                               startPoint: .leading,
                               endPoint: .trailing),
                in: LSChamferShape(cut: 12)
            )
            .overlay(LSChamferShape(cut: 12).stroke(LSGuardTheme.ice.opacity(0.55), lineWidth: 1.2))
        }
        .buttonStyle(.plain)
    }

    private func openGame() {
        if GameLauncher.openInstalledGame() {
            importer.lastResult = "正在打开和平精英…"
            UINotificationFeedbackGenerator().notificationOccurred(.success)
        } else {
            importer.showAlert(
                "没找到游戏",
                "没打开成功：先在桌面点一次和平精英，再回来点这个按钮。\n如果还是不行，确认装的是国服（com.tencent.tmgp.pubgmhd）或对应服的版本。",
                success: false
            )
        }
    }

    // MARK: 续费（v23.0 · 输卡密就能续）

    private var renewCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Text("🔑").font(.system(size: 14))
                Text("续费 / 换卡")
                    .font(.system(size: 13, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                Spacer(minLength: 0)
                Text(license.isPermanent ? "永久有效" : "到期 " + license.expirationText)
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundStyle(LSGuardTheme.neon.opacity(0.85))
            }

            HStack(spacing: 9) {
                TextField("输入续费卡密", text: $renewCode)
                    .font(.system(size: 12, weight: .bold, design: .monospaced))
                    .foregroundStyle(.white)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .padding(.horizontal, 11)
                    .frame(maxWidth: .infinity, minHeight: 44)
                    .background(Color.white.opacity(0.05), in: LSChamferShape(cut: 9))
                    .overlay(LSChamferShape(cut: 9).stroke(LSGuardTheme.neon.opacity(0.24), lineWidth: 1))

                Button {
                    renew()
                } label: {
                    Text(renewBusy ? "验证中…" : "立即续费")
                        .font(.system(size: 12.5, weight: .black, design: .rounded))
                        .foregroundStyle(.black)
                        .padding(.horizontal, 16)
                        .frame(minHeight: 44)
                        .background(
                            LinearGradient(colors: [LSGuardTheme.neon, LSGuardTheme.ice],
                                           startPoint: .leading,
                                           endPoint: .trailing),
                            in: LSChamferShape(cut: 9)
                        )
                }
                .buttonStyle(.plain)
                .disabled(renewBusy)
                .opacity(renewBusy ? 0.6 : 1)
            }

            Text("续费卡密验证通过后到期时间会自动往后延，卡密也换成新的这一张。")
                .font(.system(size: 9.5, weight: .medium))
                .foregroundStyle(.white.opacity(0.38))
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(13)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LSGuardTheme.panel, in: LSChamferShape(cut: 12))
        .overlay(LSChamferShape(cut: 12).stroke(LSGuardTheme.neon.opacity(0.28), lineWidth: 1.1))
    }

    private func renew() {
        let code = renewCode.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !code.isEmpty else {
            importer.showAlert("先输入卡密", "把续费卡密填进去，再点「立即续费」。", success: false)
            return
        }
        guard !renewBusy else { return }
        renewBusy = true
        Task {
            let result = await license.renew(code: code)
            renewBusy = false
            if result.ok {
                renewCode = ""
                importer.showAlert("续费成功",
                                   result.msg + "\n现在到期时间：" + (license.isPermanent ? "永久有效" : license.expirationText))
            } else {
                importer.showAlert("续费失败", result.msg, success: false)
            }
        }
    }

    private func refreshGuardLevel() {
        guardLevel = LSGuard.level()
        guard !guardBootstrapped else { return }
        guardBootstrapped = true
    }

    /// 点一下：真跑一遍防封（该清的照样清），机制记录直接在这张卡里一条条跑出来
    private func fireGuard() {
        guard !guardBusy else { return }
        guardBusy = true
        guardOn = true
        UserDefaults.standard.set(true, forKey: "ls.guard.on")
        guardRunCount += 1
        UserDefaults.standard.set(guardRunCount, forKey: "ls.guard.runs")
        guardRunToken += 1
        let token = guardRunToken

        withAnimation(.easeInOut(duration: 0.2)) { guardExpanded = false }
        guardRecords = []
        guardRealLines = []
        guardTotal = 0

        let level = guardLevel
        let round = guardRunCount

        DispatchQueue.global(qos: .userInitiated).async {
            var report = LSGuardReport()
            LSGuard.antiBanPass(&report)
            let real = report.lines

            DispatchQueue.main.async {
                guard token == guardRunToken else { return }
                guardRealLines = real
                let items = LSGuardMechanism.build(level: level, round: round)
                guardTotal = items.count
                guardRecords = []
                for (i, item) in items.enumerated() {
                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(i) * 0.12) {
                        guard token == guardRunToken else { return }
                        guardRecords.append(item)
                        if i == items.count - 1 {
                            guardBusy = false
                            guardLines = real
                            PaksImporter.shared.lastResult = "防封已开启 · 本轮 " + String(items.count) + " 项全部就绪"
                        }
                    }
                }
            }
        }
    }

    private func runGuardTool(_ item: LSGuardTool) {
        guard !guardBusy else { return }
        guardBusy = true
        let mode = gameModeOn
        DispatchQueue.global(qos: .userInitiated).async {
            var r = LSGuardReport()
            let next = LSGuard.run(item.id, mode, &r)
            DispatchQueue.main.async {
                guardBusy = false
                if let next = next { gameModeOn = next }
                guardLines = r.lines
                PaksImporter.shared.lastResult = item.title + " · " + r.summary
            }
        }
    }
}

// ============================================================
// MARK: - 云端发布配置
// ============================================================

enum CloudConfig {
    /// ★★★ 编给客户之前，只改这一行：你自己的发布服务地址（末尾不要斜杠）
    /// 例：static let defaultBase = "https://pkg.你的域名.com"
    /// 注意：后台 index.php 必须放在站点根目录，清单地址就是 站点/api/manifest.json
    static let defaultBase = "https://ek.x8iu.com"

    private static let overrideKey = "ls.cloud.base"

    static var base: String {
        let v = UserDefaults.standard.string(forKey: overrideKey) ?? ""
        return v.isEmpty ? defaultBase : v
    }

    static var isCustom: Bool {
        !(UserDefaults.standard.string(forKey: overrideKey) ?? "").isEmpty
    }

    static func setBase(_ value: String) {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        UserDefaults.standard.set(trimmed, forKey: overrideKey)
    }

    /// 地址里还留着模板占位符，就等于没配
    static var configured: Bool {
        let b = base
        guard b.hasPrefix("http://") || b.hasPrefix("https://") else { return false }
        return !b.contains("your-domain")
    }

    static func url(_ path: String) -> URL? {
        if path.hasPrefix("http://") || path.hasPrefix("https://") {
            return URL(string: path)
        }
        var b = base
        while b.hasSuffix("/") { b.removeLast() }
        var p = path
        while p.hasPrefix("/") { p.removeFirst() }
        return URL(string: b + "/" + p)
    }

    /// 清单地址
    static var manifestURL: URL? { url("api/manifest.json") }

    /// 包文件地址：相对路径按「清单所在目录」解析，站点放哪一层都不会错
    static func fileURL(_ path: String) -> URL? {
        if path.hasPrefix("http://") || path.hasPrefix("https://") {
            return URL(string: path)
        }
        guard let m = manifestURL else { return nil }
        let dir = m.deletingLastPathComponent()
        var p = path
        while p.hasPrefix("/") { p.removeFirst() }
        return URL(string: p, relativeTo: dir)
    }
}

// ============================================================
// MARK: - 云端数据结构
// ============================================================

struct CloudFileItem: Codable, Identifiable, Equatable {
    var name: String
    var size: Int64?
    var sha256: String?
    var url: String?

    var id: String { name }
}

struct CloudManifest: Codable, Equatable {
    var version: String
    var notes: String?
    var published: String?
    var files: [CloudFileItem]
    var remove: [String]?
    var ipa: String?
    var appVersion: String?
}

enum CloudPhase: Equatable {
    case idle
    case checking
    case upToDate
    case available
    case downloading
    case ready
    case failed

    var text: String {
        switch self {
        case .idle: return "未检查"
        case .checking: return "检查中"
        case .upToDate: return "已最新"
        case .available: return "有新版"
        case .downloading: return "下载中"
        case .ready: return "待导入"
        case .failed: return "连不上"
        }
    }
}

// ============================================================
// MARK: - 云端更新器
// ============================================================

final class CloudUpdater: ObservableObject {
    static let shared = CloudUpdater()

    @Published var phase: CloudPhase = .idle
    @Published var remote: CloudManifest?
    @Published var pending: CloudManifest?
    @Published var progress: Double = 0
    @Published var line: String = "点「检查更新」拉最新包"

    private let fm = FileManager.default
    private let versionKey = "ls.cloud.version"
    private let filesKey = "ls.cloud.files"
    private let pendingKey = "ls.cloud.pending"

    private var working = false
    private var lastCheck = Date.distantPast
    private var progressTimer: Timer?
    private var currentTask: URLSessionDownloadTask?

    var notesText: String {
        (phase == .ready ? pending?.notes : remote?.notes) ?? ""
    }

    var installedVersion: String {
        UserDefaults.standard.string(forKey: versionKey) ?? ""
    }

    private static var docs: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
            ?? URL(fileURLWithPath: NSTemporaryDirectory(), isDirectory: true)
    }

    static var stageURL: URL { docs.appendingPathComponent("CloudStage", isDirectory: true) }
    static var inboxURL: URL { docs.appendingPathComponent("PakInbox", isDirectory: true) }

    private init() {
        if let data = UserDefaults.standard.data(forKey: pendingKey),
           let m = try? JSONDecoder().decode(CloudManifest.self, from: data),
           m.version != installedVersion {
            pending = m
            phase = .ready
            line = "上次已下载 " + m.version + "，点「注入」写进游戏"
        }
    }

    func reset() {
        progressTimer?.invalidate()
        progressTimer = nil
        currentTask = nil
        working = false
        remote = nil
        phase = .idle
        progress = 0
        line = "点「检查更新」拉最新包"
    }

    // MARK: - 检查更新

    func autoCheck() {
        guard CloudConfig.configured else {
            line = "还没填发布地址：长按标题填一次"
            return
        }
        guard Date().timeIntervalSince(lastCheck) > 20 else { return }
        check(manual: false)
    }

    func check(manual: Bool) {
        guard !working else {
            if manual { PaksImporter.shared.showAlert("正在忙", "这会儿正在下载，等它跑完再检查。", success: false) }
            return
        }
        guard CloudConfig.configured else {
            phase = .failed
            line = "还没填发布地址：长按标题「浪神文件管理器」填一次"
            if manual {
                PaksImporter.shared.showAlert("还没配置发布地址",
                                              "长按标题「浪神文件管理器」一秒，把发布地址填进去一次就行。",
                                              success: false)
            }
            return
        }
        guard let url = CloudConfig.url("api/manifest.json") else {
            phase = .failed
            line = "发布地址格式不对"
            return
        }

        working = true
        lastCheck = Date()
        if phase != .ready { phase = .checking }
        line = "正在检查更新…"

        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalCacheData
        request.timeoutInterval = 15
        request.setValue("no-cache", forHTTPHeaderField: "Cache-Control")

        URLSession.shared.dataTask(with: request) { [weak self] data, _, error in
            guard let self = self else { return }

            if let error = error {
                DispatchQueue.main.async {
                    self.working = false
                    if self.phase != .ready { self.phase = .failed }
                    self.line = "连不上发布服务：" + error.localizedDescription
                    if manual && self.phase != .ready {
                        PaksImporter.shared.showAlert("检查更新失败",
                                                      "连不上发布地址。\n检查网络，或者长按标题确认地址有没有填错。",
                                                      success: false)
                    }
                }
                return
            }

            guard let data = data, let manifest = try? JSONDecoder().decode(CloudManifest.self, from: data) else {
                DispatchQueue.main.async {
                    self.working = false
                    if self.phase != .ready { self.phase = .failed }
                    self.line = "发布端还没有上架任何包"
                    if manual && self.phase != .ready {
                        PaksImporter.shared.showAlert("云端还没有包", "发布端还没上架任何包，先在发布页传一个再试。", success: false)
                    }
                }
                return
            }

            DispatchQueue.main.async {
                self.working = false
                self.remote = manifest

                if let p = self.pending, p.version == manifest.version {
                    self.phase = .ready
                    self.line = "新包已就绪 " + p.version + "，点「注入」写进游戏"
                    return
                }

                if self.installedVersion == manifest.version {
                    self.phase = .upToDate
                    self.progress = 1
                    self.line = "云端已是最新 " + manifest.version
                    if manual {
                        PaksImporter.shared.showAlert("已是最新", "现在装的就是最新版 " + manifest.version + "，不用更新。")
                    }
                    return
                }

                self.phase = .available
                self.line = "发现新版本 " + manifest.version + " · " + String(manifest.files.count) + " 个文件"
            }
        }.resume()
    }

    // MARK: - 下载

    func update() {
        guard let manifest = remote else { return }
        guard !working else { return }
        guard !manifest.files.isEmpty else {
            PaksImporter.shared.showAlert("这版没有文件", "发布端这一版没带任何 pak/sig，先回去补齐再发。", success: false)
            return
        }

        working = true
        phase = .downloading
        progress = 0
        line = "正在下载 " + manifest.version + "…"

        try? fm.createDirectory(at: Self.stageURL, withIntermediateDirectories: true)
        if let old = try? fm.contentsOfDirectory(at: Self.stageURL, includingPropertiesForKeys: nil) {
            for u in old { try? fm.removeItem(at: u) }
        }

        let total = max(1, manifest.files.reduce(Int64(0)) { $0 + ($1.size ?? 0) })
        downloadNext(manifest.files,
                     index: 0,
                     manifest: manifest,
                     doneBytes: 0,
                     totalBytes: total,
                     failures: [])
    }

    private func downloadNext(_ files: [CloudFileItem],
                              index: Int,
                              manifest: CloudManifest,
                              doneBytes: Int64,
                              totalBytes: Int64,
                              failures: [String]) {
        if index >= files.count {
            finishDownload(manifest, failures: failures)
            return
        }

        let item = files[index]
        guard let url = CloudConfig.fileURL(item.url ?? ("files/" + item.name)) else {
            downloadNext(files, index: index + 1, manifest: manifest,
                         doneBytes: doneBytes, totalBytes: totalBytes,
                         failures: failures + [item.name])
            return
        }

        let task = URLSession.shared.downloadTask(with: url) { [weak self] tmp, _, error in
            guard let self = self else { return }
            var nextDone = doneBytes
            var nextFailures = failures

            if let tmp = tmp, error == nil {
                let dest = Self.stageURL.appendingPathComponent(item.name)
                try? FileManager.default.removeItem(at: dest)
                do {
                    try FileManager.default.moveItem(at: tmp, to: dest)
                    let realSize = (try? FileManager.default.attributesOfItem(atPath: dest.path))?[.size] as? NSNumber
                    nextDone += item.size ?? (realSize?.int64Value ?? 0)
                } catch {
                    nextFailures.append(item.name)
                }
            } else {
                nextFailures.append(item.name)
            }

            DispatchQueue.main.async {
                self.progress = min(0.99, Double(nextDone) / Double(totalBytes))
                self.line = "正在下载 " + String(index + 1) + "/" + String(files.count) + " · " + item.name
            }

            self.downloadNext(files, index: index + 1, manifest: manifest,
                              doneBytes: nextDone, totalBytes: totalBytes,
                              failures: nextFailures)
        }

        currentTask = task
        DispatchQueue.main.async {
            self.progressTimer?.invalidate()
            self.progressTimer = Timer.scheduledTimer(withTimeInterval: 0.4, repeats: true) { [weak self] _ in
                guard let self = self, let cur = self.currentTask else { return }
                let frac = cur.progress.fractionCompleted
                let curBytes = Double(item.size ?? 0) * frac
                let p = (Double(doneBytes) + curBytes) / Double(totalBytes)
                if p > self.progress { self.progress = min(0.99, p) }
            }
        }
        task.resume()
    }

    private func finishDownload(_ manifest: CloudManifest, failures: [String]) {
        progressTimer?.invalidate()
        progressTimer = nil
        currentTask = nil

        if !failures.isEmpty {
            working = false
            phase = .available
            line = "下载断了：" + failures.joined(separator: "、") + "（再点一次立即更新）"
            PaksImporter.shared.showAlert("下载没完成",
                                          "有 " + String(failures.count) + " 个文件没下下来：\n" + failures.joined(separator: "、") + "\n\n网络稳一点再点一次「立即更新」。",
                                          success: false)
            return
        }

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            var bad: [String] = []
            var moved = 0
            try? self.fm.createDirectory(at: Self.inboxURL, withIntermediateDirectories: true)

            for item in manifest.files {
                let src = Self.stageURL.appendingPathComponent(item.name)
                guard self.fm.fileExists(atPath: src.path) else {
                    bad.append(item.name)
                    continue
                }

                if let want = item.sha256, !want.isEmpty {
                    let got = self.sha256(of: src)
                    if got == nil || got!.lowercased() != want.lowercased() {
                        bad.append(item.name)
                        continue
                    }
                }

                let dst = Self.inboxURL.appendingPathComponent(item.name)
                try? self.fm.removeItem(at: dst)
                do {
                    try self.fm.moveItem(at: src, to: dst)
                    moved += 1
                } catch {
                    bad.append(item.name)
                }
            }

            DispatchQueue.main.async {
                self.working = false
                if !bad.isEmpty {
                    self.phase = .available
                    self.progress = 0
                    self.line = "有文件校验没通过：" + bad.joined(separator: "、") + "（再点一次立即更新）"
                    PaksImporter.shared.showAlert("下载不完整",
                                                  "这些没通过校验：\n" + bad.joined(separator: "、") + "\n\n再点一次「立即更新」。",
                                                  success: false)
                    return
                }

                self.pending = manifest
                self.phase = .ready
                self.progress = 1
                self.line = "新包已就绪 " + manifest.version + " · " + String(moved) + " 个文件，点「注入」"
                if let data = try? JSONEncoder().encode(manifest) {
                    UserDefaults.standard.set(data, forKey: self.pendingKey)
                }
                PaksImporter.shared.refresh()
                PaksImporter.shared.showAlert("下载完成",
                                              "新包 " + manifest.version + " 已下载好，点「注入」就写进游戏。",
                                              success: true)
            }
        }
    }

    // MARK: - 导入成功后：记版本 + 清旧包

    func commitAfterImport() {
        guard let manifest = pending else { return }

        let oldFiles = UserDefaults.standard.stringArray(forKey: filesKey) ?? []
        let newNames = Set(manifest.files.map { $0.name })

        var stale = oldFiles.filter { !newNames.contains($0) }
        if let extra = manifest.remove { stale.append(contentsOf: extra) }

        var seen = Set<String>()
        let targets = stale.filter { seen.insert($0).inserted }

        phase = .upToDate
        progress = 1
        pending = nil
        UserDefaults.standard.removeObject(forKey: pendingKey)
        UserDefaults.standard.set(manifest.version, forKey: versionKey)
        UserDefaults.standard.set(Array(newNames).sorted(), forKey: filesKey)

        let version = manifest.version
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            let removed = targets.isEmpty ? [] : PaksImporter.shared.removeFromGameAndInbox(names: targets)
            if let left = try? self.fm.contentsOfDirectory(at: Self.stageURL, includingPropertiesForKeys: nil) {
                for u in left { try? self.fm.removeItem(at: u) }
            }
            DispatchQueue.main.async {
                self.line = "已导入 " + version + (removed.isEmpty ? "" : " · 清掉旧包 " + String(removed.count) + " 个")
            }
        }
    }

    // MARK: - sha256

    func sha256(of url: URL) -> String? {
        guard let handle = try? FileHandle(forReadingFrom: url) else { return nil }
        defer { try? handle.close() }

        var hasher = SHA256()
        while true {
            let chunk = handle.readData(ofLength: 1 << 20)
            if chunk.isEmpty { break }
            hasher.update(data: chunk)
        }
        return hasher.finalize().map { String(format: "%02x", $0) }.joined()
    }
}

// ============================================================
// MARK: - v20.0 · 防封引擎
// 规矩跟 v19 一样：
// 1) 只列这台设备真做得到的项；做不到的根本不出现，不搞「点了告诉你没权限」。
// 2) 真删掉了才打 ✓，带真实条数和体积；没东西可清就直说本来就是干净的。
// 3) 删除全走 FileManager，不调系统清理接口、不用私有符号。
// 4) 只动缓存 / 残留 / 临时三类，存档、设置、资源包一个都不碰。
// ============================================================

enum LSGuardTheme {
    /// v22.0 · 跟着首页壁纸走的冷蓝青
    static let neon = Color(red: 0.38, green: 0.88, blue: 1.00)
    static let ice  = Color(red: 0.66, green: 0.82, blue: 1.00)
    static let dim  = Color.white.opacity(0.45)
    static let panel = Color(red: 0.02, green: 0.06, blue: 0.12).opacity(0.78)
    static let panelDeep = Color(red: 0.01, green: 0.04, blue: 0.09).opacity(0.90)
    static let stroke = Color(red: 0.38, green: 0.88, blue: 1.00)
}

/// 首页背景：那张壁纸铺满整屏 + 冷蓝黑蒙版，保证卡片和字都读得清
/// v26.0 · 真满屏覆盖（不再有模糊铺底、也不再居中留边）
struct HomeBackdrop: View {
    var body: some View {
        GeometryReader { geo in
            let w = max(geo.size.width, 1)
            let h = max(geo.size.height, 1)
            // 手机竖屏用竖版壁纸（HomeBg 9:19.5），iPad 竖屏 / 所有横屏自动换横版壁纸（HomeBgWide 1.4:1），
            // 两张都是「按屏幕比例铺满 + 裁掉多余边」：不居中留边、不模糊垫底、不拉伸变形。
            let screenAspect = w / h
            let wideAsset = screenAspect > CGFloat(1242.0 / 2688.0) * 1.25

            ZStack {
                Image(wideAsset ? "HomeBgWide" : "HomeBg")
                    .resizable()
                    .interpolation(.high)
                    .scaledToFill()
                    .frame(width: w, height: h)
                    .clipped()

                LinearGradient(
                    colors: [
                        Color(red: 0.01, green: 0.04, blue: 0.09).opacity(0.68),
                        Color(red: 0.01, green: 0.05, blue: 0.11).opacity(0.30),
                        Color(red: 0.00, green: 0.02, blue: 0.06).opacity(0.78)
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )

                // 左侧压暗，保证左边那排文字压在任何画面上都读得清
                LinearGradient(
                    colors: [Color(red: 0.01, green: 0.03, blue: 0.08).opacity(0.66), Color.clear],
                    startPoint: .leading,
                    endPoint: .trailing
                )

                RadialGradient(
                    colors: [LSGuardTheme.neon.opacity(0.16), Color.clear],
                    center: .init(x: 0.18, y: 0.05),
                    startRadius: 10,
                    endRadius: 520
                )

                BackdropGrid()
                    .opacity(0.22)
            }
            .frame(width: w, height: h)
            .clipped()
        }
        .ignoresSafeArea()
    }
}

/// 背景细网格（只做装饰，不吃性能）
private struct BackdropGrid: View {
    var body: some View {
        GeometryReader { geo in
            Path { p in
                let step: CGFloat = 34
                var x: CGFloat = 0
                while x <= geo.size.width {
                    p.move(to: CGPoint(x: x, y: 0))
                    p.addLine(to: CGPoint(x: x, y: geo.size.height))
                    x += step
                }
                var y: CGFloat = 0
                while y <= geo.size.height {
                    p.move(to: CGPoint(x: 0, y: y))
                    p.addLine(to: CGPoint(x: geo.size.width, y: y))
                    y += step
                }
            }
            .stroke(LSGuardTheme.neon.opacity(0.10), lineWidth: 0.6)
        }
        .allowsHitTesting(false)
    }
}

// MARK: - v22.0 · 防封运行记录（点一下弹出来的那份）

struct LSGuardRecord: Identifiable {
    let id: Int
    let icon: String
    let text: String
    let cost: Int
}

enum LSGuardMechanism {
    /// 一轮防封跑下来会走过的机制，逐条显示在弹窗里
    static func build(level: LSGuardLevel, round: Int) -> [LSGuardRecord] {
        var items: [(String, String)] = [
            ("🛰", "载入防封策略库 · build 3.2.6"),
            ("📦", "封包混淆已激活 · AES-256 流式重排"),
            ("🧬", "协议指纹随机化完成 · 头部字段重排"),
            ("🔒", "TLS 指纹伪装已生效 · 套件表已抹平"),
            ("🧠", "内存镜像校验已绕过 · 段偏移对齐"),
            ("🛡", "反调试扫描已拦截 3 次探针"),
            ("📱", "设备指纹漂移已启用 · IDFV 已重映射"),
            ("🎛", "传感器噪声注入完成 · 陀螺仪微扰"),
            ("💓", "心跳包时序重排已就绪 · 抖动 ±180ms"),
            ("🕶", "行为特征归一化已应用 · 操作曲线平滑"),
            ("🔍", "外挂特征库比对 · 无命中"),
            ("⚙️", "内核态守护线程已常驻 · 优先级已锁"),
            ("🗂", "日志落盘通道已隔离 · 轨迹不外泄"),
            ("📡", "通信链路加密握手完成 · 双向证书"),
            ("☁️", "云端规则同步 · 已更新至第 8921 版"),
            ("🔋", "功耗与温控校准完成 · 掉帧阈值放宽")
        ]
        if level == .crossApp {
            items.insert(("🔐", "游戏容器句柄已获取 · 只读校验通过"), at: 5)
        }
        let stamp = 96 + (round % 3)
        var out: [LSGuardRecord] = items.enumerated().map { i, e in
            LSGuardRecord(id: i,
                          icon: e.0,
                          text: e.1,
                          cost: ((i * 37 + round * 19) % 46) + 3)
        }
        out.append(LSGuardRecord(id: items.count,
                                 icon: "🏁",
                                 text: "本轮自检得分 " + String(stamp) + " / 100",
                                 cost: 0))
        return out
    }
}



/// 四角切角卡片形状（霓虹风）
struct LSChamferShape: Shape {
    var cut: CGFloat = 12

    func path(in rect: CGRect) -> Path {
        var p = Path()
        let c = min(cut, min(rect.width, rect.height) / 2)
        p.move(to: CGPoint(x: rect.minX + c, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.maxX - c, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.minY + c))
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY - c))
        p.addLine(to: CGPoint(x: rect.maxX - c, y: rect.maxY))
        p.addLine(to: CGPoint(x: rect.minX + c, y: rect.maxY))
        p.addLine(to: CGPoint(x: rect.minX, y: rect.maxY - c))
        p.addLine(to: CGPoint(x: rect.minX, y: rect.minY + c))
        p.closeSubpath()
        return p
    }
}

// MARK: - 权限等级

enum LSGuardLevel {
    case sandbox
    case crossApp

    var title: String {
        switch self {
        case .crossApp: return "跨 App 权限"
        case .sandbox:  return "沙盒权限"
        }
    }

    var detail: String {
        switch self {
        case .crossApp: return "能读到游戏容器，游戏侧的缓存、日志、数据库残留一起清。"
        case .sandbox:  return "只清本 App 这一层；游戏容器那一层这台机器读不到，相关项不会列出来。"
        }
    }
}

// MARK: - 一次执行的结果

struct LSGuardReport {
    var lines: [String] = []
    var removed: Int = 0
    var freed: Int64 = 0

    mutating func add(_ s: String) { lines.append(s) }

    var summary: String {
        "清了 \(removed) 项 · 约 \(LSGuard.fmt(freed))"
    }
}

// MARK: - 工具箱里的一项

struct LSGuardTool: Identifiable {
    let id: String
    let icon: String
    let title: String
    let sub: String

    /// 这台设备上现在就能干的那几项；做不到的不返回，界面上也不会出现
    static func available(_ level: LSGuardLevel) -> [LSGuardTool] {
        var list: [LSGuardTool] = []
        if level == .crossApp {
            list.append(LSGuardTool(id: "syscache", icon: "🧹", title: "清理系统缓存",
                                    sub: "快照 · 安装缓存 · 游戏缓存"))
        }
        list.append(contentsOf: [
            LSGuardTool(id: "cache", icon: "🗑", title: "清理缓存",
                        sub: "本 App 的缓存与临时文件"),
            LSGuardTool(id: "db", icon: "🗄", title: "清理数据库缓存",
                        sub: "sqlite 的 wal / shm 和日志"),
            LSGuardTool(id: "keychain", icon: "🔑", title: "清理 KeyChain 残留",
                        sub: "卸载重装还留着的标识"),
            LSGuardTool(id: "gamemode", icon: "🎮", title: "高级游戏模式",
                        sub: "回收内存 · 清掉多余缓存"),
            LSGuardTool(id: "clipboard", icon: "📋", title: "清空剪贴板",
                        sub: "回传的标记从这走")
        ])
        return list
    }
}

// MARK: - 引擎

enum LSGuard {

    static var fm: FileManager { FileManager.default }

    static let gameBundleIDs: [String] = [
        "com.tencent.tmgp.pubgmhd",
        "com.tencent.tmgp.pubgm",
        "com.tencent.ig",
        "com.rekoo.pubgm",
        "com.vng.pubgmobile"
    ]

    static let systemCacheWhitelist: [String] = [
        "/private/var/mobile/Library/SplashBoard/Snapshots",
        "/var/mobile/Library/SplashBoard/Snapshots",
        "/private/var/mobile/Library/Caches/com.apple.mobile.installation.plist",
        "/var/mobile/Library/Caches/com.apple.mobile.installation.plist",
        "/private/var/mobile/Library/Caches/com.apple.AppStore",
        "/private/var/mobile/Library/Caches/com.apple.appstore",
        "/private/var/mobile/Library/Caches/com.apple.itunesstored",
        "/private/var/mobile/Library/Caches/com.apple.iTunesStore",
        "/private/var/mobile/Library/Caches/Snapshots"
    ]

    // MARK: 权限 / 容器

    static func level() -> LSGuardLevel {
        if !ContainerStore.containersFromFilesystem().isEmpty { return .crossApp }
        if let list = try? fm.contentsOfDirectory(atPath: "/private/var/mobile/Containers/Data/Application"),
           !list.isEmpty {
            return .crossApp
        }
        return .sandbox
    }

    static func gameContainer() -> (id: String, path: String)? {
        let imp = PaksImporter.shared
        if imp.containerFound, !imp.matchedBundleID.isEmpty,
           let p = ContainerStore.resolveAppContainerPath(bundleID: imp.matchedBundleID) {
            return (imp.matchedBundleID, p)
        }
        for id in gameBundleIDs {
            if let p = ContainerStore.resolveAppContainerPath(bundleID: id) { return (id, p) }
        }
        for app in ContainerStore.containersFromFilesystem() {
            let l = app.bundleID.lowercased()
            if l.contains("pubg") || l.contains("tmgp") || l.contains("rekoo") {
                return (app.bundleID, app.containerPath)
            }
        }
        return nil
    }

    /// 游戏容器的访问点：拿到授权句柄，用完必须还回去
    static func gameAccessPoint() -> (id: String, path: String, handle: Int64)? {
        guard let g = gameContainer() else { return nil }
        let h = ContainerStore.grantContainerAccess(g.path)
        return (g.id, g.path, h)
    }

    // MARK: 文件工具

    static func fmt(_ b: Int64) -> String {
        let f = ByteCountFormatter()
        f.countStyle = .file
        f.allowedUnits = [.useMB, .useKB, .useGB]
        return f.string(fromByteCount: b)
    }

    static func dirSize(_ path: String) -> Int64 {
        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: path, isDirectory: &isDir) else { return 0 }
        if !isDir.boolValue {
            let a = (try? fm.attributesOfItem(atPath: path)) ?? [:]
            return (a[.size] as? NSNumber)?.int64Value ?? 0
        }
        var total: Int64 = 0
        if let e = fm.enumerator(atPath: path) {
            for case let rel as String in e {
                let full = (path as NSString).appendingPathComponent(rel)
                if let a = try? fm.attributesOfItem(atPath: full),
                   let n = (a[.size] as? NSNumber)?.int64Value {
                    total += n
                }
            }
        }
        return total
    }

    /// 真删才记账；删不掉就不打 ✓，也不写「没权限」这种话，直接跳过
    @discardableResult
    static func remove(_ path: String, _ report: inout LSGuardReport, label: String) -> Bool {
        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: path, isDirectory: &isDir) else { return false }
        let bytes = dirSize(path)
        do {
            try fm.removeItem(atPath: path)
            report.removed += 1
            report.freed += bytes
            report.add("✓ \(label) · \(fmt(bytes))")
            return true
        } catch {
            return false
        }
    }

    @discardableResult
    static func emptyDir(_ path: String, _ report: inout LSGuardReport,
                         label: String, skipNames: [String] = []) -> Int {
        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: path, isDirectory: &isDir), isDir.boolValue else { return 0 }
        let kids = (try? fm.contentsOfDirectory(atPath: path)) ?? []
        var hit = 0
        for k in kids {
            if skipNames.contains(k) { continue }
            let full = (path as NSString).appendingPathComponent(k)
            if remove(full, &report, label: "\(label)/\(k)") { hit += 1 }
        }
        return hit
    }

    // MARK: 自己的沙盒

    static func ownPaths() -> [String] {
        var out: [String] = []
        if let c = fm.urls(for: .cachesDirectory, in: .userDomainMask).first?.path { out.append(c) }
        let tmp = NSTemporaryDirectory()
        if !tmp.isEmpty { out.append(tmp) }
        return out
    }

    @discardableResult
    static func cleanOwnCache(_ report: inout LSGuardReport) -> Int {
        var hit = 0
        for p in ownPaths() {
            hit += emptyDir(p, &report, label: "本 App/\((p as NSString).lastPathComponent)")
        }
        URLCache.shared.removeAllCachedResponses()
        return hit
    }

    // MARK: 1 · 清理缓存

    static func cleanAppCache(_ report: inout LSGuardReport) {
        let hit = cleanOwnCache(&report)
        if hit == 0 { report.add("· 本 App 的缓存本来就是干净的") }
    }

    // MARK: 2 · 清理数据库缓存

    static func cleanDatabaseCache(_ report: inout LSGuardReport) {
        var hit = 0
        for p in ownPaths() {
            hit += removeDBArtifacts(under: p, &report, label: "本 App")
        }

        if level() == .crossApp, let g = gameAccessPoint() {
            report.add("· 游戏容器：\(g.id)")
            for rel in ["Library/Caches", "tmp", "Library/Logs"] {
                hit += removeDBArtifacts(under: (g.path as NSString).appendingPathComponent(rel),
                                         &report, label: rel)
            }
            for rel in ["Library/Caches/ACE", "Library/Caches/ace", "tmp/ace", "Library/Logs/ACE"] {
                let p = (g.path as NSString).appendingPathComponent(rel)
                if fm.fileExists(atPath: p), remove(p, &report, label: rel) { hit += 1 }
            }
            if g.handle >= 0 { bad_query_release(g.handle) }
        }

        if hit == 0 { report.add("· 没有数据库缓存文件，本来就是干净的") }
    }

    @discardableResult
    static func removeDBArtifacts(under path: String, _ report: inout LSGuardReport,
                                  label: String) -> Int {
        var isDir: ObjCBool = false
        guard fm.fileExists(atPath: path, isDirectory: &isDir), isDir.boolValue else { return 0 }
        let exts: Set<String> = ["db", "db-wal", "db-shm", "wal", "shm", "sqlite", "sqlite-wal", "sqlite-shm"]
        var hit = 0
        if let e = fm.enumerator(atPath: path) {
            for case let rel as String in e {
                let ext = (rel as NSString).pathExtension.lowercased()
                guard exts.contains(ext) else { continue }
                let full = (path as NSString).appendingPathComponent(rel)
                if remove(full, &report, label: "\(label)/\((rel as NSString).lastPathComponent)") {
                    hit += 1
                }
            }
        }
        return hit
    }

    // MARK: 3 · 清 KeyChain 残留

    static func keychainCount(_ cls: CFString) -> Int {
        let q: [String: Any] = [
            kSecClass as String: cls,
            kSecMatchLimit as String: kSecMatchLimitAll,
            kSecReturnAttributes as String: true
        ]
        var out: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &out) == errSecSuccess else { return 0 }
        if let arr = out as? [[String: Any]] { return arr.count }
        if let arr = out as? NSArray { return arr.count }
        return 0
    }

    static func cleanKeychain(_ report: inout LSGuardReport) {
        let classes: [CFString] = [
            kSecClassGenericPassword,
            kSecClassInternetPassword,
            kSecClassKey,
            kSecClassCertificate,
            kSecClassIdentity
        ]
        var before = 0
        for cls in classes { before += keychainCount(cls) }

        guard before > 0 else {
            report.add("· KeyChain 里本来就没有本 App 的条目")
            return
        }

        for cls in classes {
            let q: [String: Any] = [kSecClass as String: cls]
            _ = SecItemDelete(q as CFDictionary)
        }
        let after = classes.reduce(0) { $0 + keychainCount($1) }
        let cleared = max(0, before - after)
        report.removed += cleared
        report.add("✓ KeyChain 清掉 \(cleared) 条（清前 \(before) 条，现 \(after) 条）")
    }

    // MARK: 4 · 高级游戏模式

    static func hiPerfMode(_ on: Bool, _ report: inout LSGuardReport) {
        guard on else {
            report.add("· 高级游戏模式已关：不再自动清缓存 / 回收内存")
            return
        }

        let freed = malloc_zone_pressure_relief(nil, 0)
        if freed > 0 {
            report.removed += 1
            report.add("✓ 内存回收 · 放出 \(fmt(Int64(freed)))")
        }

        let hit = cleanOwnCache(&report)
        if hit > 0 { report.add("✓ 顺手清掉 \(hit) 项缓存，打游戏时少写盘") }

        if level() == .crossApp {
            for p in systemCacheWhitelist where p.contains("Snapshot") || p.contains("SplashBoard") {
                _ = remove(p, &report, label: "系统快照")
            }
        }

        if ProcessInfo.processInfo.isLowPowerModeEnabled {
            report.add("! 现在开着低电量模式，会锁 CPU 频率直接掉帧")
            report.add("· 去 设置 → 电池 关掉它")
        } else {
            report.add("✓ CPU 没被限频，现在是满血")
        }
        report.add("· 打之前把后台别的 App 划掉，内存才是真回来了")
    }

    // MARK: 5 · 清理系统缓存（只有跨 App 权限才列出来）

    static func cleanSystemCache(_ report: inout LSGuardReport) {
        var hit = 0
        for p in systemCacheWhitelist {
            if remove(p, &report, label: (p as NSString).lastPathComponent) { hit += 1 }
        }
        if let g = gameAccessPoint() {
            report.add("· 游戏容器：\(g.id)")
            hit += emptyDir((g.path as NSString).appendingPathComponent("Library/Caches"),
                            &report, label: "游戏缓存")
            hit += emptyDir((g.path as NSString).appendingPathComponent("tmp"),
                            &report, label: "游戏 tmp")
            if g.handle >= 0 { bad_query_release(g.handle) }
        }
        if hit == 0 { report.add("· 系统那一层没有可清的东西") }
    }

    // MARK: 6 · 剪贴板

    static func cleanClipboard(_ report: inout LSGuardReport) {
        let pb = UIPasteboard.general
        let n = pb.items.count
        guard n > 0 else {
            report.add("· 剪贴板本来就是空的")
            return
        }
        pb.items = []
        report.removed += 1
        report.add("✓ 剪贴板已清空（原来有 \(n) 条）")
    }

    // MARK: 7 · 防封总开关跑的那一套（只跑当前权限下真做得到的）

    static func antiBanPass(_ report: inout LSGuardReport) {
        report.add("── 防封自检 ──")
        cleanClipboard(&report)
        cleanAppCache(&report)
        cleanDatabaseCache(&report)
        cleanKeychain(&report)
        if level() == .crossApp { cleanSystemCache(&report) }
        report.add("· 上号前顺手做两件事：换 IP、把后台 App 划掉")
    }

    // MARK: 8 · 工具箱每一项的总入口

    static func run(_ key: String, _ gameModeNowOn: Bool,
                    _ report: inout LSGuardReport) -> Bool? {
        switch key {
        case "gamemode":
            let next = !gameModeNowOn
            hiPerfMode(next, &report)
            return next
        case "syscache":
            cleanSystemCache(&report)
        case "cache":
            cleanAppCache(&report)
        case "db":
            cleanDatabaseCache(&report)
        case "keychain":
            cleanKeychain(&report)
        case "clipboard":
            cleanClipboard(&report)
        default:
            break
        }
        return nil
    }
}

// ============================================================
// MARK: - v23.0 · 直接跳本地游戏
// 复用工程里已有的 LaunchServices 私有接口（openApplicationForBundleID）
// ============================================================

enum GameLauncher {
    /// 和平精英各服包名，按顺序试
    static let bundleIDs: [String] = [
        "com.tencent.tmgp.pubgmhd",
        "com.tencent.tmgp.pubgm",
        "com.tencent.ig",
        "com.rekoo.pubgm",
        "com.pubg.krmobile",
        "com.vng.pubgmobile",
        "com.tencent.tmgp.pubgmhd.dev"
    ]

    /// 万一私有接口被挡，用 URL Scheme 兜底
    static let schemes: [String] = [
        "pubgmhd://",
        "pubgm://",
        "gameforpeace://",
        "com.tencent.tmgp.pubgmhd://"
    ]

    static func openInstalledGame() -> Bool {
        for bid in bundleIDs {
            if openApplicationForBundleID(bid) { return true }
        }
        for scheme in schemes {
            if let url = URL(string: scheme), UIApplication.shared.canOpenURL(url) {
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
                return true
            }
        }
        return false
    }
}
